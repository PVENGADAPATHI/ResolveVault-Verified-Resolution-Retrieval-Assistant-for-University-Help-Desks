import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { RefreshCcw, Cpu, Sparkles, AlertTriangle, ShieldCheck } from 'lucide-react';

interface DLMetrics {
  accuracy: number;
  f1_score: number;
  classification_report: Record<string, {
    precision: number;
    recall: number;
    'f1-score': number;
    support: number;
  }>;
}

export default function DLModule() {
  const { token, role } = useContext(AuthContext);
  const [metrics, setMetrics] = useState<DLMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [training, setTraining] = useState(false);
  const [inputText, setInputText] = useState('');
  const [prediction, setPrediction] = useState<{
    risk_level: string;
    confidence: number;
    probabilities: Record<string, number>;
    attention_weights: number[];
  } | null>(null);
  const [predicting, setPredicting] = useState(false);
  const [cacheBuster, setCacheBuster] = useState(Date.now());

  const fetchMetrics = async () => {
    try {
      const resp = await axios.get('/api/dl/metrics', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMetrics(resp.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, [token]);

  const handleTrain = async () => {
    if (!confirm("Start PyTorch Deep Learning retraining? This compiles the BiLSTM + Self-Attention networks over 10 epochs.")) return;
    setTraining(true);
    try {
      const resp = await axios.post('/api/dl/train', {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMetrics(resp.data.metadata);
      setCacheBuster(Date.now());
      alert("Deep Learning training complete! Validation accuracy reached: " + (resp.data.metadata.accuracy * 100).toFixed(2) + "%");
    } catch (e) {
      console.error(e);
      alert("Training failed.");
    } finally {
      setTraining(false);
    }
  };

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setPredicting(true);
    setPrediction(null);
    try {
      const resp = await axios.post('/api/dl/predict', { log_text: inputText }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPrediction(resp.data);
    } catch (e) {
      console.error(e);
      alert("Prediction failed.");
    } finally {
      setPredicting(false);
    }
  };

  if (loading) {
    return <Loader message="Accessing PyTorch neural layers..." />;
  }

  // Find color representing risk level
  const getRiskColor = (lvl: string) => {
    if (lvl === 'High') return 'text-brand-accent bg-brand-accent bg-opacity-10 border-brand-accent border-opacity-35';
    if (lvl === 'Medium') return 'text-brand-warning bg-brand-warning bg-opacity-10 border-brand-warning border-opacity-35';
    return 'text-brand-primary bg-brand-primary bg-opacity-10 border-brand-primary border-opacity-35';
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex justify-between items-start md:items-center flex-col md:flex-row gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-wide">Deep Learning Neural Classification</h2>
          <p className="text-xs text-gray-400 mt-1">Fine-tune BiLSTM self-attention classification layers to evaluate compliance risk severity</p>
        </div>
        {(role === 'admin' || role === 'auditor') && (
          <button
            onClick={handleTrain}
            disabled={training}
            className="glass-button-primary text-xs flex items-center gap-2"
          >
            <RefreshCcw className={`w-3.5 h-3.5 ${training ? 'animate-spin' : ''}`} />
            {training ? "Compiling Layers..." : "Train BiLSTM Attention"}
          </button>
        )}
      </div>

      {/* Grid: Metrics & Predictions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Classification Report */}
        <div className="glass-panel p-6 lg:col-span-2">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2 flex items-center justify-between">
            <span>BiLSTM Neural Classification Metrics</span>
            {metrics && (
              <span className="text-[10px] bg-brand-secondary bg-opacity-25 text-brand-secondary font-bold px-2 py-0.5 rounded">
                Weighted Accuracy: {(metrics.accuracy * 100).toFixed(2)}%
              </span>
            )}
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-dark-border text-gray-400 font-semibold uppercase">
                  <th className="py-3 px-2">Risk Category</th>
                  <th className="py-3 px-2">Precision</th>
                  <th className="py-3 px-2">Recall</th>
                  <th className="py-3 px-2">F1-Score</th>
                  <th className="py-3 px-2">Dataset Support</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-border text-gray-300">
                {metrics && Object.entries(metrics.classification_report).map(([label, val]) => {
                  if (['accuracy', 'macro avg', 'weighted avg'].includes(label)) return null;
                  return (
                    <tr key={label} className="hover:bg-dark-border hover:bg-opacity-25 transition">
                      <td className="py-3.5 px-2 font-bold">{label} Risk</td>
                      <td className="py-3.5 px-2 font-mono">{val.precision.toFixed(4)}</td>
                      <td className="py-3.5 px-2 font-mono">{val.recall.toFixed(4)}</td>
                      <td className="py-3.5 px-2 font-mono">{val['f1-score'].toFixed(4)}</td>
                      <td className="py-3.5 px-2 font-mono">{val.support}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Prediction Input */}
        <div className="glass-panel p-6 h-fit">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
            Risk Scanner
          </h3>

          <form onSubmit={handlePredict} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Audit Logs / Exceedance Description</label>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Apex discharged wastewater, measuring pH = 9.8 and Lead = 0.09 mg/L..."
                rows={4}
                required
                className="w-full glass-input text-xs resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={predicting || !inputText.trim()}
              className="w-full glass-button-primary py-2 text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2"
            >
              <Cpu className="w-4 h-4" />
              Evaluate Risk Level
            </button>
          </form>

          {/* Risk Prediction Card */}
          {prediction && (
            <div className="mt-6 p-4 rounded-xl border border-dark-border bg-dark-bg bg-opacity-40 animate-fadeIn space-y-4">
              <div className={`p-3 rounded-lg border text-center ${getRiskColor(prediction.risk_level)}`}>
                <h4 className="text-xs font-bold tracking-widest uppercase">{prediction.risk_level} RISK DETECTED</h4>
                <p className="text-[10px] opacity-75 mt-0.5">Confidence: {(prediction.confidence * 100).toFixed(1)}%</p>
              </div>

              {/* Probabilities Bars */}
              <div className="space-y-2 text-[10px]">
                {Object.entries(prediction.probabilities).map(([lvl, p]) => (
                  <div key={lvl} className="space-y-1">
                    <div className="flex justify-between font-medium">
                      <span className="text-gray-400">{lvl} Risk</span>
                      <span className="text-gray-200">{(p * 100).toFixed(1)}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-[#151B2C] rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${
                          lvl === 'High' ? 'bg-brand-accent' : lvl === 'Medium' ? 'bg-brand-warning' : 'bg-brand-primary'
                        }`} 
                        style={{ width: `${p * 100}%` }} 
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Training curves graph */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="glass-panel p-6 lg:col-span-2">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
            Neural Training Curves
          </h3>
          <div className="border border-dark-border rounded-lg overflow-hidden bg-dark-bg p-4 flex items-center justify-center h-80">
            <img 
              src={`/static/charts/dl_training_curves.png?cb=${cacheBuster}`} 
              alt="Neural Curves" 
              className="max-h-full object-contain"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><rect width="100%" height="100%" fill="%23151B2C"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%234B5563" font-size="12">BiLSTM Curves Generating...</text></svg>';
              }}
            />
          </div>
        </div>

        {/* Attention Weights Map */}
        <div className="glass-panel p-6">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-brand-primary" />
            Attention Matrix Map
          </h3>
          
          <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
            {prediction && prediction.attention_weights ? (
              <div className="flex flex-wrap gap-2 text-xs leading-relaxed p-3 border border-dark-border rounded-lg bg-dark-bg bg-opacity-30">
                {inputText.split(" ").map((word, idx) => {
                  const weight = prediction.attention_weights[idx] || 0.05;
                  // Map weight to opacity level
                  const bgOpacity = Math.min(100, Math.max(10, Math.floor(weight * 800)));
                  return (
                    <span 
                      key={idx} 
                      className="px-1.5 py-0.5 rounded text-white font-medium"
                      style={{ backgroundColor: `rgba(16, 185, 129, ${bgOpacity / 100})` }}
                      title={`Attention Weight: ${weight.toFixed(4)}`}
                    >
                      {word}
                    </span>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 text-gray-500 text-xs">
                <HelpCircle className="w-10 h-10 mx-auto text-gray-600 mb-2" />
                Run risk classifier to generate words attention coefficients mapping.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
