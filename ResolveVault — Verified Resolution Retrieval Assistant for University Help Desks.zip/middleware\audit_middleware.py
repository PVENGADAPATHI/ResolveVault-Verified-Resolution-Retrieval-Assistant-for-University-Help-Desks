import time
import sys
import os
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database.postgres import SessionLocal, AuditLog

class AuditLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        
        # Log requests to API paths
        if request.url.path.startswith("/api"):
            db = SessionLocal()
            try:
                # Basic logging of paths
                log_entry = AuditLog(
                    user_id=None,  # Set by auth endpoints
                    action="API Request",
                    details=f"Path: {request.url.path} | Method: {request.method} | Status: {response.status_code} | Time: {process_time:.4f}s"
                )
                db.add(log_entry)
                db.commit()
            except Exception as e:
                print(f"Failed to log API request: {e}")
            finally:
                db.close()
                
        return response
