from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
import sys

sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
from database.postgres import get_db, ComplianceScore, AuditLog, Notification
from api.auth import get_current_user, User

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/metrics")
def get_dashboard_metrics(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # 1. Total entities tracked
    total_entities = db.query(ComplianceScore).count()
    
    # 2. Average compliance score
    scores = db.query(ComplianceScore.overall_score).all()
    avg_score = sum(s[0] for s in scores) / len(scores) if scores else 100.0
    
    # 3. High risk count
    high_risk_count = 0
    scores_full = db.query(ComplianceScore).all()
    for s in scores_full:
        details = s.details or {}
        if details.get("violations", 0) > 2:
            high_risk_count += 1
            
    # 4. Recent audit logs
    recent_audits = db.query(AuditLog).order_back = AuditLog.timestamp.desc()
    recent_logs = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).limit(5).all()
    
    # 5. Domain distribution
    # Handled synthetically or via postgres aggregation
    domain_scores = {
        "air": sum(s.air_score for s in scores_full) / len(scores_full) if scores_full else 90.0,
        "water": sum(s.water_score for s in scores_full) / len(scores_full) if scores_full else 7.2,
        "waste": sum(s.waste_score for s in scores_full) / len(scores_full) if scores_full else 4.5
    }
    
    # Recent reports/scores list
    recent_reports = []
    for s in scores_full[:6]:
        recent_reports.append({
            "id": s.id,
            "entity_name": s.entity_name,
            "score": s.overall_score,
            "air": s.air_score,
            "water": s.water_score,
            "waste": s.waste_score,
            "evaluated_at": s.evaluated_at.strftime("%Y-%m-%d %H:%M")
        })

    return {
        "summary": {
            "total_facilities": total_entities,
            "avg_compliance_score": round(avg_score, 1),
            "high_risk_facilities": high_risk_count,
            "monitoring_status": "Active"
        },
        "domain_averages": domain_scores,
        "recent_reports": recent_reports,
        "recent_activities": [
            {
                "id": log.id,
                "user": log.user.email if log.user else "System",
                "action": log.action,
                "details": log.details,
                "timestamp": log.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            } for log in recent_logs
        ]
    }

@router.get("/notifications")
def get_notifications(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    notes = db.query(Notification).filter(Notification.user_id == current_user.id).order_by(Notification.timestamp.desc()).all()
    
    # If notifications list is empty, seed a mock notification for first login demo
    if not notes:
        n1 = Notification(
            user_id=current_user.id,
            message="Welcome to Aegis Environmental compliance auditor portal.",
            read=False
        )
        n2 = Notification(
            user_id=current_user.id,
            message="Alert: Apex Chemicals Outfall 001 pH exceeded limit (9.5 recorded).",
            read=False
        )
        db.add(n1)
        db.add(n2)
        db.commit()
        notes = [n2, n1]
        
    return [
        {
            "id": n.id,
            "message": n.message,
            "read": n.read,
            "timestamp": n.timestamp.strftime("%Y-%m-%d %H:%M")
        } for n in notes
    ]

@router.post("/notifications/{id}/read")
def mark_read(id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    note = db.query(Notification).filter(Notification.id == id, Notification.user_id == current_user.id).first()
    if note:
        note.read = True
        db.commit()
        return {"status": "success"}
    return {"status": "not_found"}
