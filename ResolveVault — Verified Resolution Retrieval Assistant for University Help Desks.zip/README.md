# Aegis - Automated Legal Research for Environmental Law Compliance

Aegis is an automated environmental auditing, legal research, and compliance monitoring platform. It parses corporate records and emissions telemetry against a hybrid vector index of environmental acts (EPA guidelines, CWA, CAA, RCRA, and State Pollution Control acts) to automatically evaluate compliance scores, detect risk severities, extract named entities, and draft legal reports.

---

## 1. Folder Structure

```
environmental_legal_compliance/
├── README.md               # Main instructions and setup guides
├── docker-compose.yml      # Service orchestration configuration
├── .env.example            # Environment variables template
├── backend/
│   ├── app.py              # Central FastAPI application server
│   ├── requirements.txt    # Python packages and AI libraries
│   ├── api/
│   │   ├── auth.py         # JWT and OAuth endpoints
│   │   ├── dashboard.py    # Analytics dashboards and notifications
│   │   ├── documents.py    # Upload routers (PDF/Word/OCR)
│   │   ├── model_ml.py     # Traditional ML endpoints
│   │   ├── model_dl.py     # PyTorch Deep Learning endpoints
│   │   ├── nlp_engine.py   # spaCy NLP tagger endpoints
│   │   ├── rag_pipeline.py # FAISS search and QA endpoints
│   │   ├── agent_loop.py   # Multi-agent AI compliance loop
│   │   ├── admin.py        # System monitoring and logs
│   │   └── genai_service.py# AI report drafts and PDF/DOCX exporters
│   ├── database/
│   │   ├── postgres.py     # SQLAlchemy models (PostgreSQL/SQLite)
│   │   ├── mongodb.py      # Async MongoDB models (Motor/Mock file)
│   │   └── redis_cache.py  # Redis memory cache client (Redis/Mock memory)
│   ├── training/
│   │   ├── train_ml.py     # Traditional ML training script
│   │   └── train_dl.py     # Deep Learning BiLSTM model trainer
│   ├── nlp/
│   │   └── processor.py    # spaCy / NLTK entity parser engine
│   ├── agents/
│   │   └── agent_officer.py# Multi-Agent loop (Planner to Response agents)
│   ├── vector_db/
│   │   └── faiss_store.py  # FAISS database client (FAISS/TF-IDF)
│   └── utils/
│       └── document_parser.py # File contents parser
├── frontend/
│   ├── package.json        # Frontend React packages
│   ├── vite.config.ts      # Vite configuration proxying /api
│   ├── tailwind.config.js  # Dark theme Tailwind styles
│   ├── index.html          # HTML Entrypoint
│   └── src/
│       ├── App.tsx         # Central App component & routes
│       ├── main.tsx        # React mounting entrypoint
│       ├── index.css       # Tailwind directives & glass styles
│       ├── components/     # Sidebar, Navbar, Loader components
│       └── pages/          # Dashboard, ML, DL, NLP, Chat, Agents, Admin
├── datasets/
│   ├── generator.py        # Generates CSV dataset and seeds DB
│   └── environmental_dataset.csv # The generated logs dataset
└── docs/
    └── project_report.md   # B.Tech B.E. Thesis Project Report
```

---

## 2. Installation Steps

### 2.1 Clone and Setup Environment
1. Navigate to the project directory:
   ```bash
   cd environmental_legal_compliance
   ```
2. Copy the environment template:
   ```bash
   copy .env.example .env
   ```
3. (Optional) Provide your Google Gemini API key inside `.env` to activate generative features, or leave it blank to automatically use our high-fidelity local templates.

---

## 3. Run Commands

### 3.1 Docker Compose Deployment (Recommended)
This runs the entire stack (FastAPI, React, PostgreSQL, MongoDB, Redis) in unified containers:
```bash
docker-compose up --build
```
Open your browser to:
- Frontend Client: `http://localhost`
- Backend API Docs (Swagger): `http://localhost/api/docs`

### 3.2 Local Run Mode (Standalone Python & Node)
If running directly on your host machine:

#### Step A: Setup Backend
1. Create a Python virtual environment and activate it:
   ```bash
   python -m venv venv
   .\venv\Scripts\activate
   ```
2. Install packages:
   ```bash
   pip install -r backend/requirements.txt
   ```
3. Generate the dataset and seed databases:
   ```bash
   python datasets/generator.py
   ```
4. Start FastAPI server:
   ```bash
   python backend/app.py
   ```
   The backend will boot on `http://localhost:8000`. Note: If local PostgreSQL/MongoDB/Redis instances are not running, the code will gracefully activate its SQLite, Mock Mongo JSON, and Mock Redis cache fallbacks automatically!

#### Step B: Setup Frontend
1. Open a new terminal window.
2. Navigate to `frontend/`:
   ```bash
   cd frontend
   ```
3. Install packages:
   ```bash
   npm install
   ```
4. Run Vite development server:
   ```bash
   npm run dev
   ```
   Open your browser to `http://localhost:5173`.

---

## 4. Testing Commands
To execute the automated API testing suite:
```bash
pytest backend/tests/
```

---

## 5. Sample Login Credentials
Use the default administrator profile to log in:
- **Email**: `admin@environmental.gov`
- **Password**: `admin123`

---

## 6. Sample Dataset Overview
The generated dataset (`datasets/environmental_dataset.csv`) contains 2,000 records tracking:
- `log_id`: Unique identification code.
- `entity_name`: Regulated facility (e.g. Apex Chemicals Ltd).
- `domain`: Medium evaluated (Air Emissions, Wastewater Discharge, Hazardous Waste).
- `log_text`: Textual summary containing stack temperatures, pH values, and lead concentrations.
- `air_level`, `water_ph`, `waste_qty`, `lead_ppm`: Numerical indicators.
- `is_violation`: Target binary classification label (0 = Compliant, 1 = Violation).
- `risk_level`: Target risk class (Low, Medium, High).

---

## 7. Sample Outputs

### 7.1 RAG Answer Output
**Query**: "What is the wastewater lead concentration limit?"  
**RAG Answer**:
> Under CWA Section 402 and NPDES guidelines, discharging toxic heavy metals such as Lead (Pb) exceeding **0.05 mg/L** into public water bodies is strictly prohibited. Discharges exceeding this threshold trigger civil audits and immediate containment actions. [Clean Water Act Section 402]

### 7.2 Multi-Agent Audit Report Output
**Input**: "Verify compliance for Apex Chemicals Ltd: wastewater discharge logged pH = 9.5 and lead = 0.08 mg/L."  
**Agentic Output**:
> # ENVIRONMENTAL COMPLIANCE AUDIT REPORT
> **Compliance Risk**: HIGH
>
> ## 1. Executive Summary
> Compliance review for Apex Chemicals Ltd reveals 2 critical regulatory infractions.
>
> ## 2. Identified Violations
> - **pH Exceedance**: pH level of 9.5 is outside the permitted NPDES range (6.0 - 8.5) [Clean Water Act Section 402].
> - **Lead Exceedance**: Lead concentration of 0.08 mg/L exceeds the EPA NPDES limit of 0.05 mg/L [Clean Water Act Section 402].
>
> ## 3. Remediation Suggestions
> 1. Halt the affected discharge line.
> 2. Implement pH neutralization and metal precipitation filters.
> 3. Disclose the exceedance to the regional Pollution Control Board within 24 hours.

---

## 8. Screenshots Description
1. **Landing Page**: Animated dark-themed landing page showcasing glowing cards representing RAG search, Multi-Agent auditing, and deep learning engines.
2. **Dashboard Console**: Main view rendering metric boxes (Avg Score, Active Alerts), interactive bar charts illustrating domain scores, and recent activity timelines.
3. **Document Hub & OCR**: Drag-and-drop file uploader area displaying processed documents, word counts, and metadata tags from PDF/DOCX parses.
4. **AI Chat Interface**: Interactive conversational agent box displaying citation badges next to summaries and foldable vector chunk inspect panels.
5. **Agentic Audits Wizard**: Screen tracking the active steps of 7 agents in real time, displaying thought summaries and nested JSON traces.

---

## 9. Viva Questions & Answers

**Q1: What is the overall architecture of this project?**  
*A*: It is a full-stack AI-native application. The frontend uses React, TypeScript, and TailwindCSS for interactive dashboards. The backend is built on FastAPI. Data is routed to PostgreSQL (relational tables like users and logs), MongoDB (documents storage), Redis (transient caches), and FAISS (local semantic vector database).

**Q2: How does the hybrid search engine work in the RAG pipeline?**  
*A*: The hybrid search combines keyword matches (TF-IDF vector matching) and semantic searches (dense vector embeddings calculated using the `all-MiniLM-L6-v2` model in FAISS). We merge these results to query both exact phrasing and underlying semantic intent, applying category filters.

**Q3: Describe the Deep Learning model architecture.**  
*A*: It is a PyTorch-based neural classifier containing:
1. Embedding layer mapping words to dense vector representations.
2. Bidirectional LSTM (BiLSTM) tracking forward and backward contextual states.
3. Self-Attention layer determining which words hold high relevance.
4. Dropout layer preventing overfitting.
5. Fully Connected layer producing probabilities for Low, Medium, and High risk.

**Q4: How did you implement database resilience (fallbacks)?**  
*A*: To make sure the platform runs out of the box in local development environments, we implemented automatic connection checks:
- PostgreSQL falls back to SQLite files.
- MongoDB falls back to a file-based JSON emulator.
- Redis falls back to an in-memory dictionary.
- FAISS falls back to a TF-IDF Cosine Similarity vector matching search.

**Q5: What are the roles of the 7 agents in the agentic compliance loop?**  
*A*: 
1. **Planner**: Creates an audit strategy.
2. **Retriever**: Queries FAISS vector stores.
3. **Research**: Identifies the limits and thresholds.
4. **Compliance**: Compares actual metrics with statutory requirements.
5. **Report**: Formulates the audit document.
6. **Verification**: Fact-checks and checks references.
7. **Final Response**: Returns clean Markdown and trace logs.
