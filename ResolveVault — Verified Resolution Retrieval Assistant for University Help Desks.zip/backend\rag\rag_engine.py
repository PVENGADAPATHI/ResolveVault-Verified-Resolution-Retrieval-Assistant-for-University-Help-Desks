import os
import sys
from dotenv import load_dotenv

# Ensure backend path
sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")

from vector_db.faiss_store import VectorDBStore
from slm.local_slm import SmallLanguageModelService

load_dotenv()

class RAGEngine:
    def __init__(self):
        self.vector_store = VectorDBStore()
        self.slm = SmallLanguageModelService()
        
    def keyword_search(self, query, top_k=3, domain_filter=None):
        chunks = self.vector_store.chunks
        if not chunks:
            return []
            
        query_words = set(query.lower().split())
        results = []
        
        for chunk in chunks:
            if domain_filter and chunk["domain"].lower() != domain_filter.lower():
                continue
                
            text_lower = chunk["text"].lower()
            # Simple term frequency score
            score = sum(1 for word in query_words if word in text_lower)
            if score > 0:
                # Normalize by chunk word count
                norm_score = score / max(1, len(query_words))
                c_copy = chunk.copy()
                c_copy["score"] = float(norm_score)
                results.append(c_copy)
                
        # Sort and take top k
        results = sorted(results, key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    def semantic_search(self, query, top_k=3, domain_filter=None):
        results = self.vector_store.search(query, top_k=top_k * 2) # Get extra to filter
        
        filtered_results = []
        for r in results:
            if domain_filter and r["domain"].lower() != domain_filter.lower():
                continue
            filtered_results.append(r)
            
        return filtered_results[:top_k]

    def hybrid_search(self, query, top_k=3, domain_filter=None):
        # Retrieve from both methods
        sem_res = self.semantic_search(query, top_k=top_k * 2, domain_filter=domain_filter)
        key_res = self.keyword_search(query, top_k=top_k * 2, domain_filter=domain_filter)
        
        # Combine using reciprocal rank fusion or simple score addition
        combined = {}
        
        # Add semantic scores (weight 0.6)
        for rank, r in enumerate(sem_res):
            key = (r["source"], r["text"])
            combined[key] = {
                "chunk": r,
                "score": r["score"] * 0.6
            }
            
        # Add keyword scores (weight 0.4)
        for rank, r in enumerate(key_res):
            key = (r["source"], r["text"])
            if key in combined:
                combined[key]["score"] += r["score"] * 0.4
            else:
                combined[key] = {
                    "chunk": r,
                    "score": r["score"] * 0.4
                }
                
        # Sort and select top k
        sorted_results = sorted(combined.values(), key=lambda x: x["score"], reverse=True)
        return [item["chunk"] for item in sorted_results[:top_k]]

    def answer_question(self, query, domain_filter=None):
        # 1. Retrieve relevant chunks
        chunks = self.hybrid_search(query, top_k=3, domain_filter=domain_filter)
        
        if not chunks:
            context = "No regulatory context found matching the query."
            citations = []
        else:
            context = "\n\n".join([f"Source: {c['source']} (Domain: {c['domain']})\nClause: {c['text']}" for c in chunks])
            citations = list(set([c["source"] for c in chunks]))
            
        # 2. Build RAG prompt
        system_prompt = (
            "You are an Environmental Law Compliance Auditor. Answer the question using ONLY the provided regulatory context. "
            "Cite your sources clearly using inline bracket syntax, e.g., '[Clean Air Act Section 112]'. "
            "If the context doesn't contain the answer, state that you cannot find the answer in current databases and recommend consulting legal experts."
        )
        
        prompt = f"REGULATORY CONTEXT:\n{context}\n\nQUESTION: {query}"
        
        answer = self.slm.generate_response(prompt, system_prompt=system_prompt)
        
        return {
            "answer": answer,
            "citations": citations,
            "retrieved_contexts": chunks
        }
