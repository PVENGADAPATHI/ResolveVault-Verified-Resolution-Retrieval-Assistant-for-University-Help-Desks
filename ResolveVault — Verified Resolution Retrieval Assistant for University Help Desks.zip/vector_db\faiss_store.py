import os
import pickle
import numpy as np
import sys

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import BASE_DIR

FAISS_AVAILABLE = False
try:
    import faiss
    from sentence_transformers import SentenceTransformer
    FAISS_AVAILABLE = True
except Exception as e:
    print(f"FAISS/SentenceTransformers not fully loaded ({e}). Using robust TF-IDF fallback for vector store.")

VECTOR_DB_DIR = os.path.join(BASE_DIR, "vector_db")
INDEX_PATH = os.path.join(VECTOR_DB_DIR, "environmental_faiss.index")
METADATA_PATH = os.path.join(VECTOR_DB_DIR, "environmental_chunks.pkl")

os.makedirs(VECTOR_DB_DIR, exist_ok=True)

class VectorDBStore:
    def __init__(self):
        self.chunks = []
        self.encoder = None
        self.index = None
        self.tfidf_vectorizer = None
        self.tfidf_matrix = None
        
        if FAISS_AVAILABLE:
            try:
                self.encoder = SentenceTransformer("all-MiniLM-L6-v2")
                self._load_or_create_index()
            except Exception as e:
                print(f"Error loading SentenceTransformer ({e}). Falling back to TF-IDF retriever.")
                self._init_tfidf_fallback()
        else:
            self._init_tfidf_fallback()

    def _init_tfidf_fallback(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        self.tfidf_vectorizer = TfidfVectorizer(stop_words='english')
        self._load_metadata_only()
        if self.chunks:
            texts = [c["text"] for c in self.chunks]
            self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(texts)

    def _load_metadata_only(self):
        if os.path.exists(METADATA_PATH):
            with open(METADATA_PATH, 'rb') as f:
                self.chunks = pickle.load(f)

    def _load_or_create_index(self):
        if os.path.exists(INDEX_PATH) and os.path.exists(METADATA_PATH):
            try:
                self.index = faiss.read_index(INDEX_PATH)
                with open(METADATA_PATH, 'rb') as f:
                    self.chunks = pickle.load(f)
                print(f"Loaded existing FAISS index with {len(self.chunks)} chunks.")
                return
            except Exception as e:
                print(f"Error reading FAISS index ({e}). Rebuilding...")
        
        self.build_initial_index()

    def chunk_text(self, text, source_title, domain, chunk_size=500, overlap=100):
        chunks = []
        clean_text = " ".join(text.split())
        start = 0
        while start < len(clean_text):
            end = min(start + chunk_size, len(clean_text))
            chunk_text = clean_text[start:end]
            chunks.append({
                "source": source_title,
                "domain": domain,
                "text": chunk_text
            })
            start += chunk_size - overlap
        return chunks

    def build_initial_index(self):
        from datasets.generator import environmental_acts
        
        all_chunks = []
        for act in environmental_acts:
            chunks = self.chunk_text(act["text"], act["title"], act["domain"])
            all_chunks.extend(chunks)
            
        self.chunks = all_chunks
        
        if self.encoder is not None:
            try:
                texts = [c["text"] for c in self.chunks]
                embeddings = self.encoder.encode(texts)
                embeddings = np.array(embeddings).astype('float32')
                
                dimension = embeddings.shape[1]
                self.index = faiss.IndexFlatL2(dimension)
                self.index.add(embeddings)
                
                faiss.write_index(self.index, INDEX_PATH)
                with open(METADATA_PATH, 'wb') as f:
                    pickle.dump(self.chunks, f)
                print(f"Successfully built and saved FAISS index with {len(self.chunks)} chunks.")
                return
            except Exception as e:
                print(f"Error building FAISS index: {e}. Reverting to TF-IDF...")
                
        from sklearn.feature_extraction.text import TfidfVectorizer
        self.tfidf_vectorizer = TfidfVectorizer(stop_words='english')
        texts = [c["text"] for c in self.chunks]
        self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(texts)
        with open(METADATA_PATH, 'wb') as f:
            pickle.dump(self.chunks, f)
        print(f"Built TF-IDF search fallback index with {len(self.chunks)} chunks.")

    def add_document(self, text, title, domain):
        new_chunks = self.chunk_text(text, title, domain)
        if not new_chunks:
            return
            
        self.chunks.extend(new_chunks)
        
        if self.encoder is not None and self.index is not None:
            try:
                texts = [c["text"] for c in new_chunks]
                embeddings = self.encoder.encode(texts)
                embeddings = np.array(embeddings).astype('float32')
                self.index.add(embeddings)
                
                faiss.write_index(self.index, INDEX_PATH)
                with open(METADATA_PATH, 'wb') as f:
                    pickle.dump(self.chunks, f)
                return
            except Exception as e:
                print(f"FAISS add failed ({e}). Rebuilding TF-IDF matrix...")
                
        if self.tfidf_vectorizer is not None:
            texts = [c["text"] for c in self.chunks]
            self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(texts)
            with open(METADATA_PATH, 'wb') as f:
                pickle.dump(self.chunks, f)

    def search(self, query, top_k=3):
        if not self.chunks:
            return []
            
        if self.encoder is not None and self.index is not None:
            try:
                query_vec = self.encoder.encode([query])
                query_vec = np.array(query_vec).astype('float32')
                distances, indices = self.index.search(query_vec, top_k)
                
                results = []
                for i, idx in enumerate(indices[0]):
                    if idx != -1 and idx < len(self.chunks):
                        chunk = self.chunks[idx].copy()
                        chunk["score"] = float(1.0 / (1.0 + distances[0][i]))
                        results.append(chunk)
                return results
            except Exception as e:
                print(f"FAISS search failed ({e}). Falling back to TF-IDF search.")
                
        if self.tfidf_vectorizer is not None and self.tfidf_matrix is not None:
            query_vec = self.tfidf_vectorizer.transform([query])
            from sklearn.metrics.pairwise import cosine_similarity
            similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
            top_indices = np.argsort(similarities)[::-1][:top_k]
            
            results = []
            for idx in top_indices:
                score = similarities[idx]
                if score > 0.0:
                    chunk = self.chunks[idx].copy()
                    chunk["score"] = float(score)
                    results.append(chunk)
            return results
            
        return []
