import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { Search, Send, FileText, Landmark, ShieldQuestion } from 'lucide-react';

interface ChatMessage {
  sender: 'user' | 'system';
  text: string;
  citations?: string[];
  contexts?: Array<{ source: string; text: string; domain: string }>;
}

export default function RAGChat() {
  const { token } = useContext(AuthContext);
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [domainFilter, setDomainFilter] = useState('');

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    const userMessage: ChatMessage = { sender: 'user', text: query };
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);
    setQuery('');

    try {
      const resp = await axios.post('/api/rag/ask', {
        question: query,
        domain_filter: domainFilter || null
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      const systemMessage: ChatMessage = {
        sender: 'system',
        text: resp.data.answer,
        citations: resp.data.citations,
        contexts: resp.data.retrieved_contexts
      };
      setMessages(prev => [...prev, systemMessage]);
    } catch (e) {
      console.error(e);
      const errorMessage: ChatMessage = {
        sender: 'system',
        text: "Apologies, the retrieval request failed. Make sure sentence-transformers or the vector index is loaded."
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn h-[calc(100vh-140px)] flex flex-col justify-between">
      
      {/* Header Info */}
      <div className="flex justify-between items-center shrink-0">
        <div>
          <h2 className="text-xl font-bold text-white tracking-wide">Regulatory Semantic RAG Engine</h2>
          <p className="text-xs text-gray-400 mt-1">Submit legal inquiries and receive answers cited from environmental databases</p>
        </div>
        <select
          value={domainFilter}
          onChange={(e) => setDomainFilter(e.target.value)}
          className="glass-input text-xs appearance-none bg-dark-panel cursor-pointer py-1.5 px-3 max-w-[200px]"
        >
          <option value="">All Domains</option>
          <option value="Air Emissions">Air Emissions</option>
          <option value="Wastewater Discharge">Wastewater Discharge</option>
          <option value="Hazardous Waste">Hazardous Waste</option>
          <option value="Chemical Safety">Chemical Safety</option>
        </select>
      </div>

      {/* Chat Display Box */}
      <div className="flex-grow glass-panel border border-dark-border p-6 overflow-y-auto my-4 space-y-6 bg-opacity-40">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center text-gray-500 space-y-3">
            <ShieldQuestion className="w-16 h-16 text-gray-600 animate-pulse" />
            <div className="max-w-md">
              <p className="text-sm font-bold text-gray-400">Ask Aegis Legal Assistant</p>
              <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                Type questions like: "What is the pH limits for industrial discharge?" or "Summarize Clean Air Act Section 112 stack criteria."
              </p>
            </div>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <div 
              key={idx} 
              className={`flex flex-col max-w-[85%] ${
                msg.sender === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'
              }`}
            >
              {/* Message text bubble */}
              <div 
                className={`p-4 rounded-2xl text-xs leading-relaxed ${
                  msg.sender === 'user' 
                    ? 'bg-brand-secondary bg-opacity-20 text-white rounded-br-none border border-brand-secondary border-opacity-35' 
                    : 'bg-dark-panel text-gray-100 rounded-bl-none border border-dark-border'
                }`}
              >
                {msg.text}
              </div>

              {/* Citations and Context Details */}
              {msg.sender === 'system' && msg.citations && msg.citations.length > 0 && (
                <div className="mt-2 space-y-1.5 text-[10px] w-full text-left">
                  <div className="flex flex-wrap gap-1.5 items-center">
                    <span className="font-semibold text-gray-500 uppercase tracking-wider">Citations:</span>
                    {msg.citations.map((cite, cIdx) => (
                      <span key={cIdx} className="bg-brand-primary bg-opacity-15 text-brand-primary font-bold px-1.5 py-0.5 rounded flex items-center gap-1 border border-brand-primary border-opacity-20">
                        <Landmark className="w-2.5 h-2.5" />
                        {cite}
                      </span>
                    ))}
                  </div>

                  {/* Retrieved Paragraph snippets */}
                  {msg.contexts && (
                    <details className="cursor-pointer text-gray-500 hover:text-gray-400">
                      <summary className="font-semibold uppercase tracking-wider text-[9px] select-none">View Retrieved Chunks Context</summary>
                      <div className="mt-2 space-y-2 border-l border-dark-border pl-3 text-gray-400 font-light">
                        {msg.contexts.map((c, ctxIdx) => (
                          <div key={ctxIdx} className="bg-dark-bg bg-opacity-30 p-2 rounded border border-dark-border">
                            <span className="font-bold text-[9px] text-gray-500 block uppercase mb-1">Chunk {ctxIdx+1} - {c.source} ({c.domain})</span>
                            "{c.text}"
                          </div>
                        ))}
                      </div>
                    </details>
                  )}
                </div>
              )}
            </div>
          ))
        )}
        
        {loading && <Loader message="Accessing FAISS vector index & running local SLM retrieval..." />}
      </div>

      {/* Input query form */}
      <form onSubmit={handleSend} className="flex gap-4 shrink-0">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Query compliance guidelines..."
          required
          disabled={loading}
          className="flex-grow glass-input text-xs"
        />
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="glass-button-primary py-2 px-5 text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5"
        >
          <Send className="w-3.5 h-3.5" />
          Send Query
        </button>
      </form>
    </div>
  );
}
