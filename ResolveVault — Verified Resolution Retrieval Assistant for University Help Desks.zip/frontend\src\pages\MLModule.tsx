import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { RefreshCcw, LineChart, FileText, CheckCircle2, AlertOctagon, HelpCircle } from 'lucide-react';

interface MLMetrics {
  best_model_name: string;
  results: Record<string, {
    accuracy: number;
    precision: number;
    recall: number;
    f1_score: number;
    auc: number;
  }>;
}

export default function MLModule() {
  const { token, role } = useContext(AuthContext);
  const [metrics, setMetrics] = useState<MLMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [training, setTraining] = useState(false);
  const [inputText, setInputText] = useState('');
  const [prediction, setPrediction] = useState<{ is_violation: number; confidence: number; best_model_used: string } | null>(null);
  const [predicting, setPredicting] = useState(false);
  
  // Cache-busting parameter for graphs
  const [cacheBuster, setCacheBuster] = useState(Date.now());

  const fetchMetrics = async () => {
    try {
      const resp = await axios.get('/api/ml/metrics', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMetrics(resp.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, [token]);

  const handleTrain = async () => {
    if (!confirm("Start ML retraining pipeline? This will retrain Logistic Regression, Random Forest, Decision Tree, SVM, and Gradient Boosting on 2,000+ logs.")) return;
    setTraining(true);
    try {
      const resp = await axios.post('/api/ml/train', {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMetrics(resp.data.metadata);
      setCacheBuster(Date.now());
      alert("Model retraining complete! Best algorithm selected: " + resp.data.metadata.best_model_name);
    } catch (e) {
      console.error(e);
      alert("Retraining failed.");
    } finally {
      setTraining(false);
    }
  };

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setPredicting(true);
    setPrediction(null);
    try {
      const resp = await axios.post('/api/ml/predict', { log_text: inputText }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPrediction(resp.data);
    } catch (e) {
      console.error(e);
      alert("Prediction request failed.");
    } finally {
      setPredicting(false);
    }
  };

  if (loading) {
    return <Loader message="Accessing pickled ML pipelines..." />;
  }

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex justify-between items-start md:items-center flex-col md:flex-row gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-wide">Traditional Machine Learning Module</h2>
          <p className="text-xs text-gray-400 mt-1">Train and deploy scikit-learn models on text classification audits</p>
        </div>
        {(role === 'admin' || role === 'auditor') && (
          <button
            onClick={handleTrain}
            disabled={training}
            className="glass-button-primary text-xs flex items-center gap-2"
          >
            <RefreshCcw className={`w-3.5 h-3.5 ${training ? 'animate-spin' : ''}`} />
            {training ? "Training..." : "Retrain ML Pipeline"}
          </button>
        )}
      </div>

      {/* Grid: Results & Interactive Predict */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Classifier table */}
        <div className="glass-panel p-6 lg:col-span-2">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2 flex items-center justify-between">
            <span>Model Comparison Metrics</span>
            {metrics && (
              <span className="text-[10px] bg-brand-primary bg-opacity-25 text-brand-primary font-bold px-2 py-0.5 rounded">
                Active Best: {metrics.best_model_name}
              </span>
            )}
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-dark-border text-gray-400 font-semibold uppercase">
                  <th className="py-3 px-2">Algorithm</th>
                  <th className="py-3 px-2">Accuracy</th>
                  <th className="py-3 px-2">Precision</th>
                  <th className="py-3 px-2">Recall</th>
                  <th className="py-3 px-2">F1 Score</th>
                  <th className="py-3 px-2">ROC-AUC</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-border text-gray-300">
                {metrics && Object.entries(metrics.results).map(([name, res]) => (
                  <tr 
                    key={name} 
                    className={`hover:bg-dark-border hover:bg-opacity-25 transition ${
                      metrics.best_model_name === name ? 'bg-brand-primary bg-opacity-[0.03] font-semibold text-white' : ''
                    }`}
                  >
                    <td className="py-3.5 px-2 flex items-center gap-2">
                      <LineChart className="w-3.5 h-3.5 text-gray-500" />
                      {name}
                    </td>
                    <td className="py-3.5 px-2 font-mono">{(res.accuracy * 100).toFixed(2)}%</td>
                    <td className="py-3.5 px-2 font-mono">{res.precision.toFixed(4)}</td>
                    <td className="py-3.5 px-2 font-mono">{res.recall.toFixed(4)}</td>
                    <td className="py-3.5 px-2 font-mono">{res.f1_score.toFixed(4)}</td>
                    <td className="py-3.5 px-2 font-mono">{res.auc.toFixed(4)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Real-time Predict */}
        <div className="glass-panel p-6 h-fit">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
            Predict Audit Log
          </h3>

          <form onSubmit={handlePredict} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Audit Log Snippet</label>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Enter air stack readings or water pH report details..."
                rows={4}
                required
                className="w-full glass-input text-xs resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={predicting || !inputText.trim()}
              className="w-full glass-button-primary py-2 text-xs font-semibold uppercase tracking-wider"
            >
              {predicting ? "Running Predict..." : "Classify Violation Status"}
            </button>
          </form>

          {/* Predictions Display */}
          {prediction && (
            <div className="mt-6 p-4 rounded-xl border border-dark-border bg-dark-bg bg-opacity-40 animate-fadeIn space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-dark-border text-xs">
                <span className="text-gray-500">Pipeline Model:</span>
                <span className="font-semibold text-brand-secondary">{prediction.best_model_used}</span>
              </div>
              <div className="flex items-center gap-3">
                {prediction.is_violation === 1 ? (
                  <>
                    <div className="w-8 h-8 rounded-lg bg-red-500 bg-opacity-[0.08] text-brand-accent flex items-center justify-center shrink-0">
                      <AlertOctagon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-brand-accent uppercase">VIOLATION DETECTED</h4>
                      <p className="text-[10px] text-gray-400 mt-0.5">Confidence: {(prediction.confidence * 100).toFixed(1)}%</p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-8 h-8 rounded-lg bg-green-500 bg-opacity-[0.08] text-brand-primary flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-brand-primary uppercase">COMPLIANT STATUS</h4>
                      <p className="text-[10px] text-gray-400 mt-0.5">Confidence: {(prediction.confidence * 100).toFixed(1)}%</p>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Evaluation Visual Charts */}
      <div className="glass-panel p-6">
        <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-6 border-b border-dark-border pb-2">
          Model Evaluation Plots
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-center text-gray-400 uppercase tracking-wider">ROC curve comparison</h4>
            <div className="border border-dark-border rounded-lg overflow-hidden bg-dark-bg p-2 h-64 flex items-center justify-center">
              <img 
                src={`/static/charts/ml_roc_comparison.png?cb=${cacheBuster}`} 
                alt="ROC Comparison" 
                className="max-h-full object-contain"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><rect width="100%" height="100%" fill="%23151B2C"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%234B5563" font-size="12">ROC Plot Generating...</text></svg>';
                }}
              />
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="text-xs font-bold text-center text-gray-400 uppercase tracking-wider">Confusion Matrix</h4>
            <div className="border border-dark-border rounded-lg overflow-hidden bg-dark-bg p-2 h-64 flex items-center justify-center">
              <img 
                src={`/static/charts/ml_confusion_matrix.png?cb=${cacheBuster}`} 
                alt="Confusion Matrix" 
                className="max-h-full object-contain"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><rect width="100%" height="100%" fill="%23151B2C"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%234B5563" font-size="12">CM Plot Generating...</text></svg>';
                }}
              />
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="text-xs font-bold text-center text-gray-400 uppercase tracking-wider">Feature Importance</h4>
            <div className="border border-dark-border rounded-lg overflow-hidden bg-dark-bg p-2 h-64 flex items-center justify-center">
              <img 
                src={`/static/charts/ml_feature_importance.png?cb=${cacheBuster}`} 
                alt="Feature Importance" 
                className="max-h-full object-contain"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><rect width="100%" height="100%" fill="%23151B2C"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%234B5563" font-size="12">Feature Plot Generating...</text></svg>';
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
