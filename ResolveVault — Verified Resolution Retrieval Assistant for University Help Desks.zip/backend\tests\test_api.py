import sys
import pytest
from fastapi.testclient import TestClient

# Ensure backend path
sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")

from app import app
from database.postgres import SessionLocal, User, init_db

client = TestClient(app)

@pytest.fixture(scope="module", autouse=True)
def setup_db():
    # Make sure DB schemas are loaded and initialized
    init_db()
    db = SessionLocal()
    # Clean up test user if exists
    test_user = db.query(User).filter(User.email == "test_officer@environmental.gov").first()
    if test_user:
        db.delete(test_user)
        db.commit()
    db.close()
    yield

def test_root_endpoint():
    resp = client.get("/")
    assert resp.status_code == 200
    assert "running successfully" in resp.json()["message"]

def test_auth_signup():
    payload = {
        "email": "test_officer@environmental.gov",
        "password": "securepassword123",
        "role": "auditor"
    }
    resp = client.post("/api/auth/signup", json=payload)
    assert resp.status_code == 200
    assert resp.json()["message"] == "User registered successfully"

def test_auth_login_and_jwt():
    form_data = {
        "username": "test_officer@environmental.gov",
        "password": "securepassword123"
    }
    resp = client.post("/api/auth/login", data=form_data)
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert data["role"] == "auditor"
    assert data["email"] == "test_officer@environmental.gov"
    
    # Store token for subsequent authenticated checks
    pytest.token = data["access_token"]

def test_authenticated_dashboard():
    headers = {"Authorization": f"Bearer {pytest.token}"}
    resp = client.get("/api/dashboard/metrics", headers=headers)
    assert resp.status_code == 200
    assert "summary" in resp.json()
    assert "recent_reports" in resp.json()

def test_nlp_analyze():
    headers = {"Authorization": f"Bearer {pytest.token}"}
    payload = {
        "text": "Apex Chemicals discharged wastewater into public streams. The pH was measured at 9.5 and lead levels were 0.08 mg/L."
    }
    resp = client.post("/api/nlp/analyze", json=payload, headers=headers)
    assert resp.status_code == 200
    data = resp.json()
    assert "keywords" in data
    assert "summary" in data
    assert len(data["environmental_entities"]) > 0

def test_ml_predict():
    headers = {"Authorization": f"Bearer {pytest.token}"}
    payload = {
        "log_text": "Daily stack emissions audit at GreenTech showed SO2 levels at 145 ppm, which is high."
    }
    resp = client.post("/api/ml/predict", json=payload, headers=headers)
    assert resp.status_code == 200
    data = resp.json()
    assert "is_violation" in data
    assert "confidence" in data

def test_dl_predict():
    headers = {"Authorization": f"Bearer {pytest.token}"}
    payload = {
        "log_text": "Hazardous waste storage logged accumulation of 19.5 tons, exceeding legal limits."
    }
    resp = client.post("/api/dl/predict", json=payload, headers=headers)
    assert resp.status_code == 200
    data = resp.json()
    assert "risk_level" in data
    assert "confidence" in data
    assert "probabilities" in data

def test_rag_search_and_ask():
    headers = {"Authorization": f"Bearer {pytest.token}"}
    
    # 1. Test search
    resp = client.get("/api/rag/search?query=pH limits&search_type=hybrid", headers=headers)
    assert resp.status_code == 200
    assert "results" in resp.json()
    
    # 2. Test Ask Q&A RAG
    payload = {
        "question": "What is the pH threshold limit for wastewater discharge under CWA Section 402?",
        "domain_filter": "Wastewater Discharge"
    }
    resp = client.post("/api/rag/ask", json=payload, headers=headers)
    assert resp.status_code == 200
    assert "answer" in resp.json()
    assert "citations" in resp.json()
