/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        dark: {
          bg: "#0B0F19",
          panel: "#151B2C",
          border: "#232D45"
        },
        brand: {
          primary: "#10B981",    // Green compliance color
          secondary: "#3B82F6",  // Blue info
          accent: "#EC4899",     // Pink alerts
          warning: "#F59E0B"     // Orange risk
        }
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
      },
      backdropBlur: {
        xs: "2px",
      }
    },
  },
  plugins: [],
}
