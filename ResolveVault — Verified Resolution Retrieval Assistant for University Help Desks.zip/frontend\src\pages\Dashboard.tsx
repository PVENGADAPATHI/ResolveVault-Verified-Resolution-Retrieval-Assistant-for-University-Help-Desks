import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { 
  Building2, Percent, AlertOctagon, Activity, 
  ArrowUpRight, RefreshCcw, Landmark 
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  PointElement,
  LineElement
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  PointElement,
  LineElement
);

interface DashboardData {
  summary: {
    total_facilities: number;
    avg_compliance_score: number;
    high_risk_facilities: number;
    monitoring_status: string;
  };
  domain_averages: {
    air: number;
    water: number;
    waste: number;
  };
  recent_reports: Array<{
    id: number;
    entity_name: string;
    score: number;
    air: number;
    water: number;
    waste: number;
    evaluated_at: string;
  }>;
  recent_activities: Array<{
    id: number;
    user: string;
    action: string;
    details: string;
    timestamp: string;
  }>;
}

export default function Dashboard() {
  const { token } = useContext(AuthContext);
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const resp = await axios.get('/api/dashboard/metrics', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setData(resp.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [token]);

  if (loading || !data) {
    return <Loader message="Compiling real-time compliance diagnostics..." />;
  }

  // Setup Chart
  const chartData = {
    labels: ['Air Quality (SO2/NOx)', 'Wastewater Quality (pH/Lead)', 'Hazardous Waste (Qty)'],
    datasets: [
      {
        label: 'Averages',
        data: [
          data.domain_averages.air, 
          data.domain_averages.water * 10,  // Scale pH for visibility
          data.domain_averages.waste * 4    // Scale waste qty for visibility
        ],
        backgroundColor: [
          'rgba(59, 130, 246, 0.4)', // blue
          'rgba(16, 185, 129, 0.4)', // green
          'rgba(245, 158, 11, 0.4)'  // orange
        ],
        borderColor: [
          '#3B82F6',
          '#10B981',
          '#F59E0B'
        ],
        borderWidth: 1.5,
        borderRadius: 8
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false
      },
      title: {
        display: true,
        text: 'Regulated Pollutant Domain Indicators (Scaled Values)',
        color: '#9CA3AF',
        font: { size: 12, weight: 'bold' as const }
      }
    },
    scales: {
      y: {
        grid: { color: '#232D45' },
        ticks: { color: '#9CA3AF' }
      },
      x: {
        grid: { display: false },
        ticks: { color: '#9CA3AF' }
      }
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Upper header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-white tracking-wide">Auditor Dashboard</h2>
          <p className="text-xs text-gray-400 mt-1">Status: Continuous regulatory monitoring loop active</p>
        </div>
        <button
          onClick={fetchDashboardData}
          className="glass-button-secondary py-2 px-3 text-xs flex items-center gap-2"
        >
          <RefreshCcw className="w-3.5 h-3.5" />
          Refresh Stats
        </button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="glass-panel p-6 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">Tracked Entities</span>
            <span className="text-3xl font-extrabold text-white mt-1 block">{data.summary.total_facilities}</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-brand-secondary bg-opacity-[0.08] text-brand-secondary flex items-center justify-center">
            <Building2 className="w-6 h-6" />
          </div>
        </div>

        <div className="glass-panel p-6 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">Avg Compliance Score</span>
            <span className="text-3xl font-extrabold text-brand-primary mt-1 block">{data.summary.avg_compliance_score}%</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-brand-primary bg-opacity-[0.08] text-brand-primary flex items-center justify-center">
            <Percent className="w-6 h-6" />
          </div>
        </div>

        <div className="glass-panel p-6 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">High Risk Violations</span>
            <span className="text-3xl font-extrabold text-brand-accent mt-1 block">{data.summary.high_risk_facilities}</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-brand-accent bg-opacity-[0.08] text-brand-accent flex items-center justify-center">
            <AlertOctagon className="w-6 h-6" />
          </div>
        </div>

        <div className="glass-panel p-6 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">Scan Telemetry</span>
            <span className="text-3xl font-extrabold text-brand-warning mt-1 block">{data.summary.monitoring_status}</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-brand-warning bg-opacity-[0.08] text-brand-warning flex items-center justify-center">
            <Activity className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Grid with Charts and Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="glass-panel p-6 lg:col-span-2">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">Pollutant Performance</h3>
          <div className="h-64 flex items-center justify-center">
            <Bar data={chartData} options={chartOptions} />
          </div>
        </div>

        <div className="glass-panel p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">Recent System Actions</h3>
            <div className="space-y-4">
              {data.recent_activities.map((act) => (
                <div key={act.id} className="flex gap-3 text-xs">
                  <div className="w-1.5 h-1.5 rounded-full bg-brand-secondary shrink-0 mt-1.5" />
                  <div className="flex-1 space-y-1">
                    <p className="font-semibold text-gray-300 leading-none">{act.action}</p>
                    <p className="text-gray-500 font-light leading-relaxed">{act.details}</p>
                    <span className="text-[10px] text-gray-600 block">{act.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Facility compliance grid */}
      <div className="glass-panel p-6">
        <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">Evaluated Environmental Audits</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-dark-border text-gray-400 font-semibold uppercase">
                <th className="py-3 px-4">Operating Facility</th>
                <th className="py-3 px-4">Overall Score</th>
                <th className="py-3 px-4">Air Level (SO2)</th>
                <th className="py-3 px-4">Water Level (pH)</th>
                <th className="py-3 px-4">Waste Qty (Tons)</th>
                <th className="py-3 px-4">Last Evaluation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-border text-gray-300">
              {data.recent_reports.map((rep) => (
                <tr key={rep.id} className="hover:bg-dark-border hover:bg-opacity-25 transition">
                  <td className="py-3.5 px-4 font-bold text-gray-100 flex items-center gap-2">
                    <Landmark className="w-3.5 h-3.5 text-gray-500" />
                    {rep.entity_name}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      rep.score > 80 
                        ? 'bg-green-500 bg-opacity-15 text-brand-primary' 
                        : rep.score > 60 
                        ? 'bg-amber-500 bg-opacity-15 text-brand-warning' 
                        : 'bg-red-500 bg-opacity-15 text-brand-accent'
                    }`}>
                      {rep.score}%
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono">{rep.air.toFixed(1)} ppm</td>
                  <td className="py-3.5 px-4 font-mono">{rep.water.toFixed(2)}</td>
                  <td className="py-3.5 px-4 font-mono">{rep.waste.toFixed(2)} Tons</td>
                  <td className="py-3.5 px-4 text-gray-500">{rep.evaluated_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
