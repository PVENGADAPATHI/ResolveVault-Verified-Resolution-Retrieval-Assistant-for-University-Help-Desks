class SimpleWordTokenizer:
    def __init__(self, max_vocab_size=5000, max_len=100):
        self.max_vocab_size = max_vocab_size
        self.max_len = max_len
        self.word2idx = {"<PAD>": 0, "<UNK>": 1}
        self.idx2word = {0: "<PAD>", 1: "<UNK>"}
        self.vocab_size = 2
        
    def fit(self, texts):
        word_counts = {}
        for text in texts:
            for word in self._clean_and_tokenize(text):
                word_counts[word] = word_counts.get(word, 0) + 1
                
        # Sort by frequency
        sorted_words = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
        for word, count in sorted_words[:self.max_vocab_size - 2]:
            self.word2idx[word] = self.vocab_size
            self.idx2word[self.vocab_size] = word
            self.vocab_size += 1
            
    def _clean_and_tokenize(self, text):
        return text.lower().replace(".", " ").replace(",", " ").replace(";", " ").split()
        
    def encode(self, text):
        tokens = self._clean_and_tokenize(text)
        encoded = []
        for token in tokens:
            encoded.append(self.word2idx.get(token, 1))  # 1 is <UNK>
        # Pad or truncate
        if len(encoded) < self.max_len:
            encoded = encoded + [0] * (self.max_len - len(encoded))
        else:
            encoded = encoded[:self.max_len]
        return encoded
