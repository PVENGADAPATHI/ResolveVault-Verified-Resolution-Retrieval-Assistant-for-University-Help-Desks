import sys
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel

sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
from api.auth import get_current_user, User
from agents.agent_officer import AgenticComplianceOfficer

router = APIRouter(prefix="/agent", tags=["Agentic AI"])
officer = AgenticComplianceOfficer()

class AgentRequest(BaseModel):
    query: str
    session_id: str = "default_session"

@router.post("/run")
def run_agentic_loop(req: AgentRequest, current_user: User = Depends(get_current_user)):
    result = officer.process_compliance_query(
        user_id=current_user.id,
        session_id=req.session_id,
        query=req.query
    )
    return result

@router.get("/history")
def get_agent_history(session_id: str = "default_session", current_user: User = Depends(get_current_user)):
    history = officer.get_session_history(
        user_id=current_user.id,
        session_id=session_id
    )
    return {
        "session_id": session_id,
        "history": history
    }
