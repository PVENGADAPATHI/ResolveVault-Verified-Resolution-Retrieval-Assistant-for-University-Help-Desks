import os
import uuid
import sys
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from typing import List

sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
from database.postgres import get_db, AuditLog
from database.mongodb import get_mongo_db
from api.auth import get_current_user, User
from utils.document_parser import DocumentParser
from vector_db.faiss_store import VectorDBStore

router = APIRouter(prefix="/documents", tags=["Documents"])
UPLOAD_DIR = "C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Shared vector DB instance
vector_store = VectorDBStore()

@router.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    domain: str = "Air Emissions", # Default domain category
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in [".pdf", ".docx", ".txt"]:
        raise HTTPException(status_code=400, detail="Only PDF, DOCX, and TXT files are supported.")
        
    # Save file to uploads folder
    file_id = str(uuid.uuid4())
    save_path = os.path.join(UPLOAD_DIR, f"{file_id}{ext}")
    try:
        with open(save_path, "wb") as f:
            f.write(await file.read())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to write file on disk: {e}")

    # Parse document text and metadata
    try:
        text, metadata = DocumentParser.parse_document(save_path)
    except Exception as e:
        os.remove(save_path) # Clean up
        raise HTTPException(status_code=500, detail=f"Failed to parse document: {e}")
        
    if not text.strip():
        os.remove(save_path)
        raise HTTPException(status_code=400, detail="Document contains no readable text.")

    # Save details to MongoDB
    mongo_db = get_mongo_db()
    document_record = {
        "_id": file_id,
        "filename": file.filename,
        "file_type": metadata.get("file_type", "TXT"),
        "raw_text": text,
        "metadata": metadata,
        "domain": domain,
        "uploader_id": current_user.id
    }
    await mongo_db["uploaded_documents"].insert_one(document_record)

    # Chunk text and insert into FAISS Vector DB
    try:
        vector_store.add_document(text, file.filename, domain)
    except Exception as e:
        print(f"Failed to index document in FAISS: {e}")
        # We don't crash, since MongoDB upload succeeded, but log it

    # Audit log
    audit = AuditLog(
        user_id=current_user.id,
        action="Document Upload",
        details=f"Uploaded: {file.filename} (Size: {metadata.get('size_bytes')} bytes, Domain: {domain})"
    )
    db.add(audit)
    db.commit()

    return {
        "message": "Document uploaded and indexed successfully",
        "document_id": file_id,
        "metadata": metadata
    }

@router.get("/list")
async def list_documents(current_user: User = Depends(get_current_user)):
    mongo_db = get_mongo_db()
    cursor = mongo_db["uploaded_documents"].find()
    docs = await cursor.to_list(length=100)
    
    # Map for client response (hide large raw_text)
    result = []
    for doc in docs:
        result.append({
            "id": doc["_id"],
            "filename": doc["filename"],
            "file_type": doc["file_type"],
            "domain": doc["domain"],
            "upload_date": doc["metadata"].get("upload_date"),
            "size_bytes": doc["metadata"].get("size_bytes"),
            "word_count": len(doc["raw_text"].split())
        })
    return result

@router.delete("/{id}")
async def delete_document(
    id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    mongo_db = get_mongo_db()
    doc = await mongo_db["uploaded_documents"].find_one({"_id": id})
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
        
    await mongo_db["uploaded_documents"].delete_one({"_id": id})
    
    # Audit log
    audit = AuditLog(
        user_id=current_user.id,
        action="Document Deletion",
        details=f"Deleted document: {doc.get('filename')} (ID: {id})"
    )
    db.add(audit)
    db.commit()
    
    return {"message": "Document deleted successfully"}
