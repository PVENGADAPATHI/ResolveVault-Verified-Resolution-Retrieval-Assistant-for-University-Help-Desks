import os
import requests
import json
import sys
import re

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import OLLAMA_URL, OLLAMA_MODEL

class SmallLanguageModelService:
    def __init__(self):
        self.ollama_active = self._check_ollama_status()
        
    def _check_ollama_status(self):
        try:
            resp = requests.get(OLLAMA_URL.replace("/generate", "/tags"), timeout=1.5)
            if resp.status_code == 200:
                print(f"Ollama connected successfully! Using model: {OLLAMA_MODEL}")
                return True
        except Exception:
            pass
        print("Ollama not reachable. Local SLM will use Rule-Based Regulatory Generator.")
        return False
        
    def generate_response(self, prompt, system_prompt="You are an environmental compliance assistant."):
        if self.ollama_active:
            try:
                payload = {
                    "model": OLLAMA_MODEL,
                    "prompt": f"{system_prompt}\n\nUser: {prompt}\nAssistant:",
                    "stream": False
                }
                resp = requests.post(OLLAMA_URL, json=payload, timeout=10)
                if resp.status_code == 200:
                    return resp.json().get("response", "").strip()
            except Exception as e:
                print(f"Ollama generation failed ({e}). Falling back to template generator...")
                
        return self._generate_fallback(prompt)

    def _generate_fallback(self, prompt):
        prompt_lower = prompt.lower()
        
        if "question" in prompt_lower or "what is" in prompt_lower or "how to" in prompt_lower:
            if "ph" in prompt_lower or "water" in prompt_lower:
                return (
                    "Based on standard environmental regulations (such as CWA Section 402 and the Indian Water Act 1974), "
                    "effluent discharge pH must be maintained between 6.0 and 8.5. Discharges outside this range are "
                    "subject to compliance enforcement, including administrative penalties. To restore compliance, "
                    "implement an active acid/base neutralization tank at the discharge outfall and monitor continuously."
                )
            elif "so2" in prompt_lower or "air" in prompt_lower:
                return (
                    "Under Clean Air Act Section 112, sulfur dioxide (SO2) emissions from industrial utility stacks "
                    "must remain below 100 ppm per hour. If emissions exceed this threshold, the facility must deploy "
                    "Flue Gas Desulfurization (FGD) scrubbers and review stack operations. Continuous Emission Monitoring "
                    "Systems (CEMS) must be calibrated immediately."
                )
            elif "waste" in prompt_lower or "rcra" in prompt_lower:
                return (
                    "RCRA Subtitle C stipulates that large quantity generators cannot accumulate hazardous waste "
                    "exceeding 10 tons per month or retain it on-site for more than 90 days without a permit. "
                    "Establish a manifest tracking system and arrange transport via licensed EPA waste handlers."
                )
            return (
                "Environmental compliance guidelines require strict tracking of emission thresholds, pollutant discharge points, "
                "and hazardous waste manifests. Ensure all monitoring systems are calibrated and report violations "
                "to the state Pollution Control Board or regional EPA authorities within 24 hours of discovery."
            )
            
        elif "summarize" in prompt_lower or "summary" in prompt_lower:
            act_match = self.re_search(r"(clean air act|clean water act|rcra|water act|air act)", prompt_lower)
            act_name = act_match.upper() if act_match else "Regulatory standard"
            return (
                f"### Executive Compliance Summary: {act_name}\n"
                "1. **Core Obligation**: Established strict limits on chemical discharges and stack emissions.\n"
                "2. **Critical Thresholds**: Air limits are capped at 100 ppm SO2 / 120 ppm NOx. Water pH must stand between 6.0-8.5.\n"
                "3. **Enforcement Scope**: Failure to comply triggers civil audits, containment notices, and administrative shut-down procedures."
            )
            
        else:
            return (
                "### SLM Compliance Action Plan\n"
                "1. **Audit Logs**: Establish a continuous monitoring loop (CEMS/Outfall telemetry) to detect spikes early.\n"
                "2. **Neutralization**: Install pH buffering systems and filtration loops for effluent discharge lines.\n"
                "3. **Waste Segregation**: Store toxic waste in double-walled drums and label with chemical hazard codes.\n"
                "4. **Immediate Report**: If an exceedance is confirmed, log the duration, concentration, and actions taken in the audit registry."
            )

    def re_search(self, pattern, text):
        match = re.search(pattern, text)
        return match.group(1) if match else None
