import os
import pickle
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_curve, auc, confusion_matrix

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_PATH = os.path.join(BASE_DIR, "datasets/environmental_dataset.csv")

MODELS_DIR = os.path.join(BASE_DIR, "backend/models/ml")
MODELS_DIRS = [
    MODELS_DIR,
    os.path.join(BASE_DIR, "models/ml")
]
CHARTS_DIR = os.path.join(BASE_DIR, "backend/static/charts")

for d in MODELS_DIRS:
    os.makedirs(d, exist_ok=True)
os.makedirs(CHARTS_DIR, exist_ok=True)

def train_and_evaluate_ml():
    if not os.path.exists(DATASET_PATH):
        print("Dataset not found! Please run dataset generator first.")
        return None
        
    df = pd.read_csv(DATASET_PATH)
    
    vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
    X = vectorizer.fit_transform(df['log_text']).toarray()
    y = df['is_violation'].values
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    models = {
        "Logistic Regression": LogisticRegression(random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
        "Decision Tree": DecisionTreeClassifier(random_state=42),
        "SVM": SVC(probability=True, random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42)
    }
    
    results = {}
    plt.figure(figsize=(10, 8))
    
    best_model_name = None
    best_f1 = 0
    best_model = None
    
    for name, model in models.items():
        print(f"Training {name}...")
        model.fit(X_train, y_train)
        
        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)[:, 1]
        
        acc = accuracy_score(y_test, y_pred)
        precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='binary')
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        roc_auc = auc(fpr, tpr)
        
        results[name] = {
            "accuracy": float(acc),
            "precision": float(precision),
            "recall": float(recall),
            "f1_score": float(f1),
            "auc": float(roc_auc)
        }
        
        plt.plot(fpr, tpr, label=f'{name} (AUC = {roc_auc:.3f})')
        
        if f1 > best_f1:
            best_f1 = f1
            best_model_name = name
            best_model = model
            
    plt.plot([0, 1], [0, 1], 'k--', label='Random Guess')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve Comparison')
    plt.legend(loc='lower right')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, "ml_roc_comparison.png"), dpi=150)
    plt.close()
    
    y_pred_best = best_model.predict(X_test)
    cm = confusion_matrix(y_test, y_pred_best)
    
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Compliant', 'Violation'], yticklabels=['Compliant', 'Violation'])
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.title(f'Confusion Matrix - {best_model_name}')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, "ml_confusion_matrix.png"), dpi=150)
    plt.close()
    
    rf_model = models["Random Forest"]
    importances = rf_model.feature_importances_
    indices = np.argsort(importances)[::-1][:15]
    feature_names = np.array(vectorizer.get_feature_names_out())
    
    plt.figure(figsize=(10, 6))
    plt.title("Top 15 Feature Importances (Random Forest)")
    plt.bar(range(15), importances[indices], align="center")
    plt.xticks(range(15), feature_names[indices], rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, "ml_feature_importance.png"), dpi=150)
    plt.close()
    
    # Save files to both folders
    for d in MODELS_DIRS:
        with open(os.path.join(d, "vectorizer.pkl"), 'wb') as f:
            pickle.dump(vectorizer, f)
        with open(os.path.join(d, "best_model.pkl"), 'wb') as f:
            pickle.dump(best_model, f)
            
        metadata = {
            "best_model_name": best_model_name,
            "results": results
        }
        with open(os.path.join(d, "ml_metadata.pkl"), 'wb') as f:
            pickle.dump(metadata, f)
            
    print(f"ML Pipeline complete. Best Model: {best_model_name} with F1-Score: {best_f1:.4f}")
    return metadata

if __name__ == "__main__":
    train_and_evaluate_ml()
