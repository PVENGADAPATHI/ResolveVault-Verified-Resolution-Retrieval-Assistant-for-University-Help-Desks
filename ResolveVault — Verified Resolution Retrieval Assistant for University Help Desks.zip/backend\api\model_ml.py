import os
import pickle
import sys
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel

sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
from database.postgres import get_db, AuditLog
from api.auth import get_current_user, User
from training.train_ml import train_and_evaluate_ml, MODELS_DIR

router = APIRouter(prefix="/ml", tags=["Machine Learning"])

class PredictRequest(BaseModel):
    log_text: str

class PredictResponse(BaseModel):
    is_violation: int
    confidence: float
    best_model_used: str

@router.post("/train")
def trigger_training(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if current_user.role not in ["admin", "auditor"]:
        raise HTTPException(status_code=403, detail="Unauthorized role. Admins/Auditors only.")
        
    try:
        metadata = train_and_evaluate_ml()
        
        # Log audit
        audit = AuditLog(
            user_id=current_user.id,
            action="ML Model Retrained",
            details=f"Best Model: {metadata['best_model_name']} with F1: {metadata['results'][metadata['best_model_name']]['f1_score']:.4f}"
        )
        db.add(audit)
        db.commit()
        
        return {
            "message": "Traditional ML training complete.",
            "metadata": metadata
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"ML training failed: {str(e)}")

@router.get("/metrics")
def get_ml_metrics(current_user: User = Depends(get_current_user)):
    meta_path = os.path.join(MODELS_DIR, "ml_metadata.pkl")
    if not os.path.exists(meta_path):
        # Trigger fallback train to seed initial metrics if files are not on disk yet
        try:
            metadata = train_and_evaluate_ml()
            return metadata
        except Exception:
            raise HTTPException(status_code=404, detail="No ML model metadata found. Please train models first.")
            
    with open(meta_path, 'rb') as f:
        metadata = pickle.load(f)
    return metadata

@router.post("/predict", response_model=PredictResponse)
def predict_compliance(req: PredictRequest, current_user: User = Depends(get_current_user)):
    vec_path = os.path.join(MODELS_DIR, "vectorizer.pkl")
    model_path = os.path.join(MODELS_DIR, "best_model.pkl")
    meta_path = os.path.join(MODELS_DIR, "ml_metadata.pkl")
    
    if not os.path.exists(vec_path) or not os.path.exists(model_path):
        # Auto-train if models are missing
        train_and_evaluate_ml()
        if not os.path.exists(vec_path) or not os.path.exists(model_path):
            raise HTTPException(status_code=500, detail="Models missing and auto-training failed.")
            
    with open(vec_path, 'rb') as f:
        vectorizer = pickle.load(f)
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    with open(meta_path, 'rb') as f:
        meta = pickle.load(f)
        
    try:
        # Transform input
        vec = vectorizer.transform([req.log_text]).toarray()
        pred = model.predict(vec)[0]
        proba = model.predict_proba(vec)[0]
        confidence = float(proba[pred])
        
        return {
            "is_violation": int(pred),
            "confidence": confidence,
            "best_model_used": meta["best_model_name"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")
