import sys
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from typing import Optional

sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
from api.auth import get_current_user, User
from rag.rag_engine import RAGEngine

router = APIRouter(prefix="/rag", tags=["RAG & Search Engine"])
rag_engine = RAGEngine()

class RAGQuestionRequest(BaseModel):
    question: str
    domain_filter: Optional[str] = None

@router.get("/search")
def search_regulations(
    query: str,
    search_type: str = "hybrid", # semantic, keyword, hybrid
    domain: Optional[str] = None,
    limit: int = 5,
    current_user: User = Depends(get_current_user)
):
    if search_type == "semantic":
        results = rag_engine.semantic_search(query, top_k=limit, domain_filter=domain)
    elif search_type == "keyword":
        results = rag_engine.keyword_search(query, top_k=limit, domain_filter=domain)
    else:
        results = rag_engine.hybrid_search(query, top_k=limit, domain_filter=domain)
        
    return {
        "query": query,
        "search_type": search_type,
        "results": results
    }

@router.post("/ask")
def ask_rag_engine(req: RAGQuestionRequest, current_user: User = Depends(get_current_user)):
    result = rag_engine.answer_question(req.question, domain_filter=req.domain_filter)
    return result
