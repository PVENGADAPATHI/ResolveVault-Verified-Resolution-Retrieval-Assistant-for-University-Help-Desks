import os
import redis
import sys
from dotenv import load_dotenv

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import REDIS_HOST, REDIS_PORT, REDIS_DB

class MockRedis:
    def __init__(self):
        self.store = {}
        
    def get(self, key):
        return self.store.get(key)
        
    def set(self, key, value, ex=None):
        self.store[key] = value
        return True
        
    def delete(self, key):
        if key in self.store:
            del self.store[key]
            return 1
        return 0
        
    def incr(self, key):
        val = self.store.get(key, 0)
        try:
            val = int(val) + 1
        except ValueError:
            val = 1
        self.store[key] = str(val)
        return val
        
    def ping(self):
        return True

try:
    redis_client = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB, socket_timeout=2)
    redis_client.ping()
    print("Redis connection successful!")
except Exception as e:
    print(f"Redis connection failed ({e}). Falling back to in-memory Mock Redis...")
    redis_client = MockRedis()

def get_redis_client():
    return redis_client
