from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

class ExceptionHandlingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)
        except Exception as e:
            print(f"Global unhandled exception caught: {e}")
            return JSONResponse(
                status_code=500,
                content={"detail": f"An unexpected system error occurred: {str(e)}"}
            )
