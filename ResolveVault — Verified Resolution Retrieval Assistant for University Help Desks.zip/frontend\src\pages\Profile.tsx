import React, { useContext, useState } from 'react';
import { AuthContext } from '../App.tsx';
import { User, Shield, Calendar, Key, Star, History, Bookmark, CheckSquare } from 'lucide-react';

export default function Profile() {
  const { email, role } = useContext(AuthContext);
  
  // Mocking profile audit history/bookmarks for compliance sweeps demonstration
  const [bookmarks, setBookmarks] = useState([
    { id: "1", title: "Clean Air Act - Major Stack limits Section 112", date: "2026-07-06" },
    { id: "2", title: "NPDES Wastewater standard limits (pH and Lead)", date: "2026-07-06" }
  ]);

  const [history, setHistory] = useState([
    { query: "Apex Chemicals SO2 stack readings", date: "2026-07-06", type: "RAG Search" },
    { query: "Wastewater pH limit exceedance risk evaluation", date: "2026-07-06", type: "DL Predict" },
    { query: "RCRA Title C waste quantity requirements", date: "2026-07-05", type: "RAG Search" }
  ]);

  return (
    <div className="space-y-8 animate-fadeIn text-xs">
      <div>
        <h2 className="text-xl font-bold text-white tracking-wide">Legal Officer Profile</h2>
        <p className="text-xs text-gray-400 mt-1">Manage compliance credentials, saved benchmarks, and search history</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Profile Card */}
        <div className="glass-panel p-6 h-fit space-y-6">
          <div className="flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-full bg-brand-primary bg-opacity-[0.08] text-brand-primary flex items-center justify-center text-2xl font-bold border border-brand-primary border-opacity-35 mb-4 shadow-xl">
              🛡️
            </div>
            <h3 className="text-sm font-bold text-white">{email}</h3>
            <span className="text-[10px] bg-brand-secondary bg-opacity-25 text-brand-secondary font-bold px-2 py-0.5 rounded-full mt-1.5 uppercase">
              {role} Role
            </span>
          </div>

          <div className="border-t border-dark-border pt-4 space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-500">Department</span>
              <span className="text-gray-300 font-semibold">Environmental Legal Audits</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Security Clearance</span>
              <span className="text-gray-300 font-semibold">{role === 'admin' ? 'Level 3 - Global Administrator' : 'Level 2 - Auditor'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Account Created</span>
              <span className="text-gray-300 font-semibold">2026-07-06</span>
            </div>
          </div>
        </div>

        {/* Bookmarks and Audit History */}
        <div className="glass-panel p-6 lg:col-span-2 space-y-6">
          
          {/* Saved Bookmarks */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider border-b border-dark-border pb-2 flex items-center gap-1.5">
              <Bookmark className="w-4 h-4 text-brand-primary" />
              Saved Bookmarks ({bookmarks.length})
            </h3>
            <div className="space-y-2">
              {bookmarks.map(b => (
                <div key={b.id} className="flex justify-between items-center p-3 rounded-lg border border-dark-border bg-dark-bg bg-opacity-40">
                  <span className="text-gray-200 font-semibold">{b.title}</span>
                  <span className="text-[10px] text-gray-500">{b.date}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Audit History */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider border-b border-dark-border pb-2 flex items-center gap-1.5">
              <History className="w-4 h-4 text-brand-secondary" />
              Search & Audit History ({history.length})
            </h3>
            <div className="space-y-2">
              {history.map((h, idx) => (
                <div key={idx} className="flex justify-between items-center p-3 rounded-lg border border-dark-border bg-dark-bg bg-opacity-40">
                  <div>
                    <p className="text-gray-200 font-semibold">"{h.query}"</p>
                    <span className="text-[9px] text-gray-500 block mt-0.5">{h.type}</span>
                  </div>
                  <span className="text-[10px] text-gray-500">{h.date}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
