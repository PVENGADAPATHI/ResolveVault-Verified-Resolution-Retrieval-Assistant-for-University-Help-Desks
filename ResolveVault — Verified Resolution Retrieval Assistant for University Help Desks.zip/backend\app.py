import os
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

# Load env variables
load_dotenv()

# Import routers
from api import auth, dashboard, documents, model_ml, model_dl, nlp_engine, rag_pipeline, agent_loop, admin, genai_service
from database.postgres import init_db
from vector_db.faiss_store import VectorDBStore

app = FastAPI(
    title="Aegis - Environmental compliance auditor API",
    description="Automated Legal Research & Compliance audit portal for Environmental Law compliance.",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Startup events
@app.on_event("startup")
def startup_event():
    print("Starting up Aegis API...")
    # Initialize Postgres schemas and seed admin
    try:
        init_db()
    except Exception as e:
        print(f"PostgreSQL init skipped/failed ({e}). Working in fallback DB mode.")
        
    # Seed FAISS index with initial Environmental Law Acts
    try:
        store = VectorDBStore()
        # Trigger index build if empty
        if not store.chunks:
            store.build_initial_index()
    except Exception as e:
        print(f"FAISS initialization skipped ({e}). Working in local search fallback.")

# Mount static folder to serve generated charts (ROC, confusion matrix, training curves)
CHARTS_DIR = "C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend/static"
os.makedirs(CHARTS_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=CHARTS_DIR), name="static")

# Map Routers
app.include_router(auth.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
app.include_router(documents.router, prefix="/api")
app.include_router(model_ml.router, prefix="/api")
app.include_router(model_dl.router, prefix="/api")
app.include_router(nlp_engine.router, prefix="/api")
app.include_router(rag_pipeline.router, prefix="/api")
app.include_router(agent_loop.router, prefix="/api")
app.include_router(admin.router, prefix="/api")
app.include_router(genai_service.router, prefix="/api")

@app.get("/")
def read_root():
    return {"message": "Aegis Environmental Compliance auditor API running successfully."}

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
