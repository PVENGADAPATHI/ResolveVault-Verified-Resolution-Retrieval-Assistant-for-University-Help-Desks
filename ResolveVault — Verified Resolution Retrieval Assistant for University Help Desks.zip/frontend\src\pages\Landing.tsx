import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, Sparkles, FileText, Search, Bot, Database, BarChart4, Cpu } from 'lucide-react';

export default function Landing() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6, ease: "easeOut" } }
  };

  const features = [
    { title: "Document Hub & OCR", desc: "Ingest environmental permits, acts, and corporate audits in PDF, Word, or plain text with simulated OCR scanning.", icon: FileText },
    { title: "Hybrid Search & RAG", desc: "Retrieve legal clauses using unified keyword and vector FAISS indexes, prompting SLMs with citations.", icon: Search },
    { title: "Multi-Agent System", desc: "Engage a team of 7 autonomous agents collaborating via memory to planner-audit compliance issues.", icon: Bot },
    { title: "Deep Learning Risk Tagger", desc: "Classify compliance risk levels (Low, Medium, High) using a custom PyTorch BiLSTM Attention model.", icon: Cpu },
    { title: "ML Classifier Playground", desc: "Train and evaluate Logistic Regression, Random Forest, Decision Tree, SVM, and Gradient Boosting models.", icon: Database },
    { title: "Advanced Analytics & Exports", desc: "Export formatted auditing notices and compliance impact evaluations directly to PDF or Word DOCX format.", icon: BarChart4 },
  ];

  return (
    <div className="min-h-screen bg-dark-bg text-gray-100 flex flex-col items-center justify-between relative overflow-hidden">
      {/* Decorative neon blobs */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-brand-primary bg-opacity-[0.06] filter blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] rounded-full bg-brand-secondary bg-opacity-[0.06] filter blur-[150px] pointer-events-none" />

      {/* Landing Navbar */}
      <header className="w-full max-w-7xl px-6 h-20 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🛡️</span>
          <span className="font-extrabold text-xl tracking-wider bg-gradient-to-r from-brand-primary to-brand-secondary bg-clip-text text-transparent">
            AEGIS AUDITOR
          </span>
        </div>
        <div className="flex items-center gap-4">
          <Link to="/login" className="text-sm font-medium text-gray-400 hover:text-white transition">Sign In</Link>
          <Link to="/register" className="glass-button-primary text-xs py-2 px-4">Register</Link>
        </div>
      </header>

      {/* Hero Section */}
      <main className="w-full max-w-7xl px-6 flex-grow flex flex-col items-center justify-center text-center z-10 py-12 md:py-20">
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="max-w-4xl space-y-6 md:space-y-8"
        >
          <motion.div variants={itemVariants} className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-brand-primary border-opacity-35 bg-brand-primary bg-opacity-[0.07] text-brand-primary text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" /> Environmental Law Compliance Automation
          </motion.div>
          
          <motion.h2 variants={itemVariants} className="text-4xl md:text-6xl font-extrabold leading-tight tracking-tight text-white">
            Automated Legal Research & Compliance <br className="hidden md:inline" />
            <span className="bg-gradient-to-r from-brand-primary via-[#2DD4BF] to-brand-secondary bg-clip-text text-transparent">
              Auditing Powered by AI
            </span>
          </motion.h2>

          <motion.p variants={itemVariants} className="text-base md:text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed">
            Ensure environmental standard conformity. Aegis integrates Hybrid Search, RAG retrieval citations, PyTorch Deep Learning classifiers, and 7 cooperative agents to streamline compliance logs monitoring.
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link to="/login" className="glass-button-primary px-8 py-3.5 text-sm font-semibold tracking-wide w-full sm:w-auto">
              Launch Compliance Panel
            </Link>
            <Link to="/register" className="glass-button-secondary px-8 py-3.5 text-sm font-semibold tracking-wide w-full sm:w-auto">
              Create Free Audit Account
            </Link>
          </motion.div>
        </motion.div>

        {/* Feature Grid */}
        <section className="w-full max-w-7xl pt-24 pb-12">
          <h3 className="text-2xl font-bold text-white mb-12 text-center uppercase tracking-widest border-b border-dark-border pb-4 max-w-xs mx-auto">
            Aegis Key Features
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
            {features.map((feat, idx) => (
              <div key={idx} className="glass-panel p-6 hover:border-brand-primary hover:border-opacity-40 transition-all duration-300 group">
                <div className="w-10 h-10 rounded-lg bg-brand-primary bg-opacity-[0.08] text-brand-primary flex items-center justify-center mb-4 group-hover:scale-110 transition duration-300">
                  <feat.icon className="w-5 h-5" />
                </div>
                <h4 className="text-lg font-bold text-gray-100 mb-2">{feat.title}</h4>
                <p className="text-xs text-gray-400 leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-dark-border h-16 flex items-center justify-center text-xs text-gray-500 z-10 bg-dark-panel bg-opacity-30">
        © 2026 Aegis Environmental Auditor Inc. All statutory rights reserved.
      </footer>
    </div>
  );
}
