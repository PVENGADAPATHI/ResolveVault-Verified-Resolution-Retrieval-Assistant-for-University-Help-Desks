import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { FileUp, FileText, Trash2, Calendar, Database, HardDrive, CheckCircle } from 'lucide-react';

interface DocumentItem {
  id: string;
  filename: string;
  file_type: string;
  domain: string;
  upload_date: string;
  size_bytes: number;
  word_count: number;
}

export default function Documents() {
  const { token } = useContext(AuthContext);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [file, setFile] = useState<File | null>(null);
  const [domain, setDomain] = useState('Air Emissions');
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const fetchDocuments = async () => {
    try {
      const resp = await axios.get('/api/documents/list', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setDocuments(resp.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, [token]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('domain', domain);

    try {
      await axios.post('/api/documents/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`
        }
      });
      setFile(null);
      fetchDocuments();
      alert("Document uploaded and indexed successfully!");
    } catch (err: any) {
      console.error(err);
      alert(err.response?.data?.detail || "Upload failed. Verify document contents.");
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this document? It will be removed from MongoDB and RAG index search space.")) return;
    try {
      await axios.delete(`/api/documents/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setDocuments(prev => prev.filter(doc => doc.id !== id));
    } catch (e) {
      console.error(e);
      alert("Delete failed.");
    }
  };

  if (loading) {
    return <Loader message="Accessing MongoDB document registry..." />;
  }

  return (
    <div className="space-y-8 animate-fadeIn">
      <div>
        <h2 className="text-xl font-bold text-white tracking-wide">Environmental Regulation Registry</h2>
        <p className="text-xs text-gray-400 mt-1">Upload Environmental Acts, NPDES Permitting limits, or facility reports</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Upload Form Panel */}
        <div className="glass-panel p-6 h-fit">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
            Ingest Document
          </h3>
          
          <form onSubmit={handleUpload} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Category Medium</label>
              <select
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                className="w-full glass-input text-sm appearance-none bg-dark-panel cursor-pointer"
              >
                <option value="Air Emissions">Air Emissions (CAA Section 112)</option>
                <option value="Wastewater Discharge">Wastewater Discharge (CWA Section 402)</option>
                <option value="Hazardous Waste">Hazardous Waste (RCRA Subtitle C)</option>
                <option value="Chemical Safety">Chemical Safety (UN Stockholm POPs)</option>
              </select>
            </div>

            {/* Drag & Drop Area */}
            <div 
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer transition ${
                dragActive 
                  ? 'border-brand-primary bg-brand-primary bg-opacity-[0.03]' 
                  : 'border-dark-border hover:border-brand-secondary hover:bg-dark-panel hover:bg-opacity-40'
              }`}
              onClick={() => document.getElementById('file-input')?.click()}
            >
              <input
                id="file-input"
                type="file"
                onChange={handleFileChange}
                accept=".pdf,.docx,.txt"
                className="hidden"
              />
              <FileUp className="w-10 h-10 text-gray-500 mb-3 group-hover:scale-110 transition" />
              
              {file ? (
                <div className="text-center space-y-1">
                  <p className="text-xs font-bold text-gray-200 max-w-[200px] truncate mx-auto">{file.name}</p>
                  <p className="text-[10px] text-gray-500">{(file.size / 1024).toFixed(1)} KB</p>
                </div>
              ) : (
                <div className="text-center">
                  <p className="text-xs font-semibold text-gray-300">Drag & Drop or Click to browse</p>
                  <p className="text-[10px] text-gray-500 mt-1">Supports PDF, DOCX, or TXT (Max 10MB)</p>
                </div>
              )}
            </div>

            {uploading ? (
              <Loader message="Extracting text & indexing in FAISS..." />
            ) : (
              <button
                type="submit"
                disabled={!file}
                className="w-full glass-button-primary py-2 text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Database className="w-4 h-4" />
                Upload & Parse
              </button>
            )}
          </form>
        </div>

        {/* Documents List Grid */}
        <div className="glass-panel p-6 lg:col-span-2">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
            Ingested Statutes ({documents.length})
          </h3>

          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
            {documents.length === 0 ? (
              <div className="text-center py-16 text-gray-500 space-y-2">
                <FileText className="w-12 h-12 mx-auto text-gray-600" />
                <p className="text-xs">No environmental regulations indexed yet.</p>
              </div>
            ) : (
              documents.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-4 rounded-xl border border-dark-border bg-dark-panel bg-opacity-40 hover:border-brand-secondary transition">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-brand-secondary bg-opacity-[0.08] text-brand-secondary flex items-center justify-center shrink-0 mt-0.5">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-gray-200 truncate pr-4">{doc.filename}</h4>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-[10px] text-gray-500 font-medium">
                        <span className="bg-[#1c2438] px-2 py-0.5 rounded text-gray-400 font-semibold">{doc.domain}</span>
                        <span className="flex items-center gap-1"><HardDrive className="w-3 h-3" /> {(doc.size_bytes / 1024).toFixed(1)} KB</span>
                        <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {doc.upload_date}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDelete(doc.id)}
                    className="p-2 rounded-lg text-gray-500 hover:bg-red-500 hover:bg-opacity-10 hover:text-red-400 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
