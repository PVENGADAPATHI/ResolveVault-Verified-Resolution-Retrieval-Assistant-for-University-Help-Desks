import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { Tag, Sparkles, AlertCircle, FileText, CheckCircle, SearchCode } from 'lucide-react';

interface NLPAnalysisResult {
  tokens: string[];
  lemmas: string[];
  pos_tags: Array<[string, string]>;
  ner_entities: Array<{ text: string; label: string; start: number; end: number }>;
  environmental_entities: Array<{ text: string; label: string; start: number; end: number }>;
  detected_clauses: Array<{ sentence_idx: number; text: string; type: string }>;
  keywords: string[];
  summary: string;
}

export default function NLPModule() {
  const { token } = useContext(AuthContext);
  const [inputText, setInputText] = useState('');
  const [result, setResult] = useState<NLPAnalysisResult | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setAnalyzing(true);
    setResult(null);
    try {
      const resp = await axios.post('/api/nlp/analyze', { text: inputText }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setResult(resp.data);
    } catch (e) {
      console.error(e);
      alert("NLP processing request failed.");
    } finally {
      setAnalyzing(false);
    }
  };

  const getEntityLabelColor = (label: string) => {
    if (label === 'CHEMICAL') return 'bg-brand-accent bg-opacity-20 text-brand-accent border-brand-accent';
    if (label === 'LIMIT_VALUE') return 'bg-brand-warning bg-opacity-20 text-brand-warning border-brand-warning';
    if (label === 'ACT_SECTION') return 'bg-brand-secondary bg-opacity-20 text-brand-secondary border-brand-secondary';
    return 'bg-brand-primary bg-opacity-20 text-brand-primary border-brand-primary';
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div>
        <h2 className="text-xl font-bold text-white tracking-wide">Natural Language Text Processor</h2>
        <p className="text-xs text-gray-400 mt-1">Sift, tokenize, tag parts-of-speech, and parse environmental entities and legal sections</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* NLP Input Panel */}
        <div className="glass-panel p-6 h-fit">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
            Ingest Audit Passage
          </h3>

          <form onSubmit={handleAnalyze} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Raw Regulations / Compliance Logs</label>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Paste in regulations or chemical logs to run POS NER and clauses extracts..."
                rows={8}
                required
                className="w-full glass-input text-xs resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={analyzing || !inputText.trim()}
              className="w-full glass-button-primary py-2 text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2"
            >
              <SearchCode className="w-4 h-4" />
              Analyze Text Layers
            </button>
          </form>
        </div>

        {/* NLP Results Container */}
        <div className="glass-panel p-6 lg:col-span-2">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
            Text Parsing Diagnostics
          </h3>

          {analyzing && <Loader message="Running NLTK cleaning & spaCy pipeline..." />}

          {!analyzing && !result && (
            <div className="text-center py-20 text-gray-500 space-y-2">
              <Sparkles className="w-12 h-12 mx-auto text-gray-600 animate-pulse" />
              <p className="text-xs">Paste and submit text to view NLP analysis results.</p>
            </div>
          )}

          {!analyzing && result && (
            <div className="space-y-6 animate-fadeIn text-xs">
              
              {/* Extractive Summary */}
              <div className="space-y-2 p-4 rounded-xl border border-dark-border bg-dark-bg bg-opacity-40">
                <h4 className="font-bold text-gray-200 uppercase tracking-wide flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-brand-secondary" /> Extractive Summary
                </h4>
                <p className="text-gray-300 leading-relaxed">{result.summary || "Summary generation skipped due to short text."}</p>
              </div>

              {/* Environmental Entities (Custom NER) */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-400 uppercase tracking-wider">Extracted Environmental Entities</h4>
                <div className="flex flex-wrap gap-2">
                  {result.environmental_entities.length === 0 ? (
                    <span className="text-gray-500 font-light">No specialized chemical or limit values found</span>
                  ) : (
                    result.environmental_entities.map((ent, idx) => (
                      <span 
                        key={idx} 
                        className={`px-2.5 py-1 rounded border text-[10px] font-bold ${getEntityLabelColor(ent.label)}`}
                      >
                        {ent.text} ({ent.label})
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Detected Clauses */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-400 uppercase tracking-wider">Identified Regulatory Clauses</h4>
                <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                  {result.detected_clauses.length === 0 ? (
                    <span className="text-gray-500 font-light">No compliance thresholds or exceedances identified</span>
                  ) : (
                    result.detected_clauses.map((clause, idx) => (
                      <div 
                        key={idx} 
                        className={`p-3 rounded-lg border flex gap-2.5 items-start ${
                          clause.type === 'VIOLATION_RISK' 
                            ? 'bg-red-500 bg-opacity-10 border-red-500 border-opacity-35 text-red-400' 
                            : 'bg-green-500 bg-opacity-10 border-green-500 border-opacity-35 text-brand-primary'
                        }`}
                      >
                        {clause.type === 'VIOLATION_RISK' ? (
                          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        ) : (
                          <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="font-bold uppercase text-[9px] tracking-widest">{clause.type}</p>
                          <p className="mt-1 leading-relaxed text-gray-200">{clause.text}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Keywords */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-400 uppercase tracking-wider">Keyword Density (Lemmatized)</h4>
                <div className="flex flex-wrap gap-2">
                  {result.keywords.map((kw, idx) => (
                    <span key={idx} className="bg-[#1c2438] text-gray-300 px-2 py-1 rounded flex items-center gap-1">
                      <Tag className="w-3 h-3 text-gray-500" />
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
