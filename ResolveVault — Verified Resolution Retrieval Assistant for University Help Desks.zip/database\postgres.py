import os
import datetime
import sys
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

# Add project root to sys path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import POSTGRES_URL, SQLITE_URL

# Fallback mechanism
try:
    engine = create_engine(POSTGRES_URL, connect_args={"connect_timeout": 3} if "postgresql" in POSTGRES_URL else {})
    with engine.connect() as conn:
        pass
    print("PostgreSQL connection successful!")
except Exception as e:
    print(f"PostgreSQL connection failed ({e}). Falling back to SQLite...")
    engine = create_engine(SQLITE_URL, connect_args={"check_same_thread": False} if "sqlite" in SQLITE_URL else {})

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=True) # Nullable for OAuth
    role = Column(String, default="user") # admin, auditor, user
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    oauth_provider = Column(String, nullable=True) # google, github
    
    audit_logs = relationship("AuditLog", back_populates="user")
    notifications = relationship("Notification", back_populates="user")
    bookmarks = relationship("Bookmark", back_populates="user")

class ComplianceScore(Base):
    __tablename__ = "compliance_scores"
    
    id = Column(Integer, primary_key=True, index=True)
    entity_name = Column(String, index=True, nullable=False)
    overall_score = Column(Float, nullable=False)
    air_score = Column(Float, nullable=False)
    water_score = Column(Float, nullable=False)
    waste_score = Column(Float, nullable=False)
    evaluated_at = Column(DateTime, default=datetime.datetime.utcnow)
    details = Column(JSON, nullable=True)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    details = Column(String, nullable=True)
    
    user = relationship("User", back_populates="audit_logs")

class Notification(Base):
    __tablename__ = "notifications"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    message = Column(String, nullable=False)
    read = Column(Boolean, default=False)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    
    user = relationship("User", back_populates="notifications")

class Bookmark(Base):
    __tablename__ = "bookmarks"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    doc_id = Column(String, nullable=False)
    title = Column(String, nullable=False)
    saved_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    user = relationship("User", back_populates="bookmarks")

def init_db():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    from passlib.hash import bcrypt
    admin_user = db.query(User).filter(User.email == "admin@environmental.gov").first()
    if not admin_user:
        hashed = bcrypt.hash("admin123")
        new_admin = User(email="admin@environmental.gov", password_hash=hashed, role="admin")
        db.add(new_admin)
        db.commit()
        print("Admin user seeded: admin@environmental.gov / admin123")
    db.close()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
