import React, { createContext, useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Landing from './pages/Landing.tsx';
import Login from './pages/Login.tsx';
import Register from './pages/Register.tsx';
import Dashboard from './pages/Dashboard.tsx';
import Documents from './pages/Documents.tsx';
import MLModule from './pages/MLModule.tsx';
import DLModule from './pages/DLModule.tsx';
import NLPModule from './pages/NLPModule.tsx';
import RAGChat from './pages/RAGChat.tsx';
import AgenticAI from './pages/AgenticAI.tsx';
import Analytics from './pages/Analytics.tsx';
import AdminPanel from './pages/AdminPanel.tsx';
import Profile from './pages/Profile.tsx';
import Sidebar from './components/Sidebar.tsx';
import Navbar from './components/Navbar.tsx';

interface AuthContextType {
  token: string | null;
  role: string | null;
  email: string | null;
  login: (token: string, role: string, email: string) => void;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType>({
  token: null,
  role: null,
  email: null,
  login: () => {},
  logout: () => {}
});

const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
  const token = localStorage.getItem('token');
  return token ? <>{children}</> : <Navigate to="/login" replace />;
};

const AppLayout = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();
  const hideSidebar = ['/', '/login', '/register'].includes(location.pathname);
  
  if (hideSidebar) return <>{children}</>;
  
  return (
    <div className="flex min-h-screen bg-dark-bg text-gray-100 overflow-x-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 md:pl-64">
        <Navbar />
        <main className="flex-grow p-6 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [role, setRole] = useState<string | null>(localStorage.getItem('role'));
  const [email, setEmail] = useState<string | null>(localStorage.getItem('email'));

  const login = (jwtToken: string, userRole: string, userEmail: string) => {
    localStorage.setItem('token', jwtToken);
    localStorage.setItem('role', userRole);
    localStorage.setItem('email', userEmail);
    setToken(jwtToken);
    setRole(userRole);
    setEmail(userEmail);
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('email');
    setToken(null);
    setRole(null);
    setEmail(null);
  };

  return (
    <AuthContext.Provider value={{ token, role, email, login, logout }}>
      <Router>
        <AppLayout>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            
            {/* Private Routes */}
            <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
            <Route path="/documents" element={<PrivateRoute><Documents /></PrivateRoute>} />
            <Route path="/ml" element={<PrivateRoute><MLModule /></PrivateRoute>} />
            <Route path="/dl" element={<PrivateRoute><DLModule /></PrivateRoute>} />
            <Route path="/nlp" element={<PrivateRoute><NLPModule /></PrivateRoute>} />
            <Route path="/rag" element={<PrivateRoute><RAGChat /></PrivateRoute>} />
            <Route path="/agentic" element={<PrivateRoute><AgenticAI /></PrivateRoute>} />
            <Route path="/analytics" element={<PrivateRoute><Analytics /></PrivateRoute>} />
            <Route path="/admin" element={<PrivateRoute><AdminPanel /></PrivateRoute>} />
            <Route path="/profile" element={<PrivateRoute><Profile /></PrivateRoute>} />
            
            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AppLayout>
      </Router>
    </AuthContext.Provider>
  );
}
