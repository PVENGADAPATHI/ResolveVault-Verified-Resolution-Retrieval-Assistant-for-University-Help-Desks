import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { Sparkles, FileText, Download, FileCode, CheckSquare, AlertCircle } from 'lucide-react';

export default function Analytics() {
  const { token } = useContext(AuthContext);
  const [reportType, setReportType] = useState('compliance_report');
  const [entityName, setEntityName] = useState('Apex Chemicals Ltd');
  const [violations, setViolations] = useState('pH level exceeded permitted limits; sulfur dioxide stack emissions breached CAA Section 112 thresholds');
  const [riskLevel, setRiskLevel] = useState('High');
  const [details, setDetails] = useState('Wastewater discharge logged pH = 9.5 and lead = 0.08 mg/L. Air stack emissions measured SO2 = 145 ppm.');
  
  const [generatedReport, setGeneratedReport] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [exporting, setExporting] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);
    setGeneratedReport(null);

    const violationList = violations.split(";").map(v => v.trim()).filter(v => v.length > 0);

    try {
      const resp = await axios.post('/api/genai/report', {
        report_type: reportType,
        entity_name: entityName,
        violations: violationList,
        risk_level: riskLevel,
        details: details
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setGeneratedReport(resp.data.content);
    } catch (e) {
      console.error(e);
      alert("Failed to generate compliance report.");
    } finally {
      setGenerating(false);
    }
  };

  const handleExport = async (format: 'pdf' | 'docx') => {
    if (!generatedReport) return;
    setExporting(true);

    try {
      const filename = `${entityName.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${reportType}`;
      const resp = await axios.post(`/api/genai/export/${format}`, {
        content: generatedReport,
        filename: filename
      }, {
        headers: { Authorization: `Bearer ${token}` },
        responseType: 'blob' // Important for file downloads
      });

      // Create browser download link
      const blob = new Blob([resp.data], { 
        type: format === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' 
      });
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `${filename}.${format}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error(e);
      alert(`Failed to export report as ${format.toUpperCase()}.`);
    } finally {
      setExporting(false);
    }
  };

  const reportTitles: Record<string, string> = {
    compliance_report: 'Compliance Audit Report',
    violation_report: 'Official Violation Notice',
    legal_notice: 'Statutory Legal Notice Notice',
    risk_assessment: 'Environmental Risk Assessment',
    impact_summary: 'Ecological Impact Summary'
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div>
        <h2 className="text-xl font-bold text-white tracking-wide">Environmental compliance Reports & Analytics</h2>
        <p className="text-xs text-gray-400 mt-1">Draft legal audit documents and export directly to PDF or DOCX</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Parameters Form */}
        <div className="glass-panel p-6 h-fit">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
            Audit Parameters
          </h3>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Report Document Class</label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="w-full glass-input text-xs appearance-none bg-dark-panel cursor-pointer"
              >
                <option value="compliance_report">Compliance Audit Report</option>
                <option value="violation_report">Official Violation Report</option>
                <option value="legal_notice">Formal Legal Notice Draft</option>
                <option value="risk_assessment">Environmental Risk Assessment</option>
                <option value="impact_summary">Ecological Impact Summary</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Facility name</label>
              <input
                type="text"
                value={entityName}
                onChange={(e) => setEntityName(e.target.value)}
                required
                className="w-full glass-input text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Risk Severity</label>
              <select
                value={riskLevel}
                onChange={(e) => setRiskLevel(e.target.value)}
                className="w-full glass-input text-xs appearance-none bg-dark-panel cursor-pointer"
              >
                <option value="Low">Low Risk (Compliant)</option>
                <option value="Medium">Medium Risk</option>
                <option value="High">High Risk (Critical Violations)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Documented Violations (Separate with semicolon ';')</label>
              <textarea
                value={violations}
                onChange={(e) => setViolations(e.target.value)}
                rows={3}
                required
                className="w-full glass-input text-xs resize-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Additional Operations Data</label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                rows={3}
                className="w-full glass-input text-xs resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={generating}
              className="w-full glass-button-primary py-2 text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              {generating ? "Drafting Report..." : "Draft Audit Report"}
            </button>
          </form>
        </div>

        {/* Report Output Area */}
        <div className="glass-panel p-6 lg:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center pb-2 border-b border-dark-border mb-4">
              <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider">
                {generatedReport ? reportTitles[reportType] : "Report Document Workspace"}
              </h3>
              {generatedReport && (
                <div className="flex gap-2">
                  <button
                    onClick={() => handleExport('pdf')}
                    disabled={exporting}
                    className="glass-button-secondary py-1 px-2.5 text-[10px] flex items-center gap-1.5 bg-[#151B2C] border-brand-primary border-opacity-30 hover:border-opacity-100"
                  >
                    <Download className="w-3 h-3 text-brand-primary" />
                    PDF
                  </button>
                  <button
                    onClick={() => handleExport('docx')}
                    disabled={exporting}
                    className="glass-button-secondary py-1 px-2.5 text-[10px] flex items-center gap-1.5 bg-[#151B2C] border-brand-secondary border-opacity-30 hover:border-opacity-100"
                  >
                    <Download className="w-3 h-3 text-brand-secondary" />
                    DOCX
                  </button>
                </div>
              )}
            </div>

            {generating && <Loader message="Generating customized legal draft report using AI services..." />}

            {!generating && !generatedReport && (
              <div className="text-center py-32 text-gray-500 space-y-2">
                <FileText className="w-16 h-16 mx-auto text-gray-600 animate-pulse" />
                <p className="text-xs">Adjust parameters and click generate to populate document workspace.</p>
              </div>
            )}

            {!generating && generatedReport && (
              <div className="p-5 rounded-xl border border-dark-border bg-dark-bg bg-opacity-40 max-h-[450px] overflow-y-auto animate-fadeIn">
                <pre className="text-xs font-sans text-gray-300 whitespace-pre-wrap leading-relaxed">
                  {generatedReport}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
