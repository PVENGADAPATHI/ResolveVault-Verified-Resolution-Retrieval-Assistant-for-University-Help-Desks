import React, { useContext } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { AuthContext } from '../App.tsx';
import { 
  LayoutDashboard, FileText, BrainCircuit, LineChart, 
  Binary, Search, Bot, BarChart3, ShieldAlert, User, LogOut 
} from 'lucide-react';

export default function Sidebar() {
  const { logout, role } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Document Hub & OCR', path: '/documents', icon: FileText },
    { name: 'Traditional ML', path: '/ml', icon: LineChart },
    { name: 'Deep Learning', path: '/dl', icon: BrainCircuit },
    { name: 'NLP Analyzer', path: '/nlp', icon: Binary },
    { name: 'RAG Search', path: '/rag', icon: Search },
    { name: 'Agentic AI Officer', path: '/agentic', icon: Bot },
    { name: 'Analytics & Reports', path: '/analytics', icon: BarChart3 },
    { name: 'Profile Settings', path: '/profile', icon: User },
  ];

  // Only show Admin route if role is admin
  if (role === 'admin') {
    navItems.push({ name: 'Admin Dashboard', path: '/admin', icon: ShieldAlert });
  }

  return (
    <aside className="fixed inset-y-0 left-0 z-20 flex-col w-64 hidden md:flex bg-dark-panel border-r border-dark-border">
      <div className="flex items-center gap-3 px-6 h-16 border-b border-dark-border">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-brand-primary bg-opacity-20 text-brand-primary">
          🛡️
        </div>
        <span className="font-extrabold text-lg bg-gradient-to-r from-brand-primary to-brand-secondary bg-clip-text text-transparent">
          AEGIS AUDITOR
        </span>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) => 
              `flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-150 ${
                isActive 
                  ? 'bg-brand-primary bg-opacity-15 text-brand-primary border-l-2 border-brand-primary' 
                  : 'text-gray-400 hover:bg-dark-border hover:bg-opacity-40 hover:text-gray-200'
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            {item.name}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-dark-border">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 w-full px-4 py-3 rounded-lg text-sm font-medium text-gray-400 hover:bg-red-500 hover:bg-opacity-10 hover:text-red-400 transition-all duration-150"
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
