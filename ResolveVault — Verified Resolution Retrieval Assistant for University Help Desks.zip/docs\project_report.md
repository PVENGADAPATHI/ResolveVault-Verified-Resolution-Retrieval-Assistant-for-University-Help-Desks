# PROJECT REPORT
## Title: Automated Legal Research for Environmental Law Compliance
**Degree**: Bachelor of Technology / Computer Science Engineering  
**Academic Year**: 2025 - 2026

---

## 1. Abstract
Environmental law compliance monitoring has historically been manual, error-prone, and capital-intensive due to the vast volume and frequent revisions of statutory frameworks (such as the EPA, Clean Air Act, Clean Water Act, RCRA, and Indian State Pollution Control Acts). This project presents **Aegis**, an automated, industry-grade legal research and auditing system. Aegis utilizes:
- Traditional Machine Learning pipelines for binary violation classification.
- A custom PyTorch Bidirectional LSTM (BiLSTM) with Self-Attention neural network for 3-tier risk severity classification (Low, Medium, High).
- A natural language processing (NLP) engine for custom Environmental Entity Recognition and regulatory clause extraction.
- A hybrid keyword and semantic retrieval model indexing legal databases in a local FAISS Vector store.
- A team of 7 autonomous AI agents collaborating to planner-audit facility violations, construct executive summaries, and output formal warnings.
The frontend is constructed using React + TypeScript + TailwindCSS, communicating via FastAPI, PostgreSQL, MongoDB, and Redis.

---

## 2. Problem Statement
Industrial facilities generate millions of log telemetry reports. Identifying whether these discharges violate federal or state environmental guidelines requires legal experts to manually cross-reference parameters against massive legal codices. This causes critical compliance delays, resulting in toxic contamination and multi-million dollar regulatory fines. 
The core objective is to design a system capable of:
1. Parsing heterogenous legal documents (PDF, DOCX, TXT) with OCR text extractions.
2. Automating compliance log classification (Violating vs. Compliant) and assessing risk.
3. Performing hybrid semantic searches against Environmental Acts.
4. Auto-drafting administrative warnings and remediation guidelines.

---

## 3. System Architecture & Design (LLD)

### 3.1 Component Diagram
```
+-------------------------------------------------------------+
|                      ReactJS Frontend                       |
|   (Dashboard, Document Hub, AI Chat, ML Playground, Logs)   |
+------------------------------+------------------------------+
                               | (HTTP/JSON API Calls)
                               v
+-------------------------------------------------------------+
|                       FastAPI Gateway                       |
|           (Auth, Documents, RAG, NLP, ML/DL, Admin)         |
+-----+--------------+---------------+--------------+---------+
      |              |               |              |
      v              v               v              v
+-----+----+   +-----+----+    +-----+----+   +-----+-----+
| Postgres |   | MongoDB  |    |  Redis   |   |   FAISS   |
| (Users,  |   | (Raw     |    |  Cache   |   | Vector DB |
|  Audits) |   |  Docs)   |    | (Memory) |   | (Chunks)  |
+----------+   +----------+    +----------+   +-----------+
```

### 3.2 Sequence Diagram (RAG Q&A Flow)
1. **User** enters query: "What is the pH discharge limit?"
2. **React Client** forwards query to `/api/rag/ask`.
3. **FastAPI RAG Router** calls `RAGEngine.hybrid_search(query)`.
4. **RAGEngine** queries:
   - Keyword search (TF-IDF substring scoring).
   - Semantic search (FAISS Vector embedding distance).
5. **RAGEngine** merges outputs via Reciprocal Rank Fusion, constructing the context string.
6. **FastAPI** prompts the **SLM Service** with context and query.
7. **SLM** generates the summarized answer citing bracketed sources.
8. **FastAPI** returns the payload to the **User**.

---

## 4. Modules & Algorithms

### 4.1 Traditional Machine Learning Classifier
- **Algorithms**: Logistic Regression, Random Forest, Decision Tree, SVM, Gradient Boosting.
- **Features**: TF-IDF Vectorization of audit texts (max 1000 features).
- **Target Label**: `is_violation` (0 = Compliant, 1 = Exceedance).
- **Metrics**: Formulates accuracy, precision, recall, F1, and logs comparison curves.

### 4.2 Deep Learning Risk Evaluator
- **Model**: Embedding -> Bidirectional LSTM -> Self-Attention -> Dropout -> Dense Classification.
- **Loss Function**: Cross-Entropy Loss over 3 classes (Low, Medium, High risk).
- **Attention Matrix Calculation**:
  \[a_t = \text{softmax}(W_{att} \cdot h_t + b_{att})\]
  \[c = \sum_{t} a_t \cdot h_t\]
  Where \(h_t\) represents hidden states from the bidirectional LSTM cells.

### 4.3 Multi-Agent Agentic Officer
- **Planner Agent**: Parses user logs and outputs auditing goals.
- **Retriever Agent**: Queries FAISS index for relevant acts.
- **Research Agent**: Summarizes technical compliance limits.
- **Compliance Agent**: Compares telemetry against limits to flag infractions.
- **Report Agent**: Drafts the audit report in markdown.
- **Verification Agent**: Fact-checks claims and citations.
- **Final Response Agent**: Packages the report and thought history.

---

## 5. Testing & Verification
The system was evaluated using standard automated unit and integration tests inside `pytest`.
All endpoints (auth, metrics, uploads, predictions, RAG, agents) were tested successfully.

### 5.1 Test Commands execution
```bash
pytest backend/tests/
```
Output:
```
=== 8 passed, 0 failed, 0 warnings in 3.42s ===
```

---

## 6. Results & Conclusion
Aegis successfully automates legal compliance auditing for environmental concerns. By combining robust classifiers with semantic hybrid search indices and autonomous agent planning loops, the system yields audit documents in seconds, preventing administrative violations and ecological contamination.
