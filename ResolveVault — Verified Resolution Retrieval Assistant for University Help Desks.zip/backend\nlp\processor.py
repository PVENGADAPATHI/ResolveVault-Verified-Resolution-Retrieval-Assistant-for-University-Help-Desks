import os
import re
import spacy
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize

# Setup NLTK data path and downloads
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('averaged_perceptron_tagger', quiet=True)
except Exception as e:
    print(f"Error initializing NLTK downloads: {e}")

# Safe tokenizers fallback
def safe_sent_tokenize(text):
    try:
        return sent_tokenize(text)
    except Exception:
        # Fallback split sentences on period, exclamation, question mark
        sents = re.split(r'(?<=[.!?])\s+', text)
        return [s.strip() for s in sents if s.strip()]

def safe_word_tokenize(text):
    try:
        return word_tokenize(text)
    except Exception:
        return text.split()

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_sm")
except Exception:
    print("spaCy model 'en_core_web_sm' not found. Installing via subprocess...")
    import subprocess
    import sys
    try:
        subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
        nlp = spacy.load("en_core_web_sm")
    except Exception as err:
        print(f"Subprocess installation failed ({err}). Using fallback blank spaCy model.")
        nlp = spacy.blank("en")

class LegalNLPProcessor:
    def __init__(self):
        try:
            self.stop_words = set(stopwords.words('english'))
        except Exception:
            # Fallback static stopword list if nltk corpus is not downloaded
            self.stop_words = set([
                "i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", "yours", 
                "yourself", "yourselves", "he", "him", "his", "himself", "she", "her", "hers", "herself", 
                "it", "its", "itself", "they", "them", "their", "theirs", "themselves", "what", "which", 
                "who", "whom", "this", "that", "these", "those", "am", "is", "are", "was", "were", "be", 
                "been", "being", "have", "has", "had", "having", "do", "does", "did", "doing", "a", "an", 
                "the", "and", "but", "if", "or", "because", "as", "until", "while", "of", "at", "by", "for", 
                "with", "about", "against", "between", "into", "through", "during", "before", "after", 
                "above", "below", "to", "from", "up", "down", "in", "out", "on", "off", "over", "under", 
                "again", "further", "then", "once", "here", "there", "when", "where", "why", "how", "all", 
                "any", "both", "each", "few", "more", "most", "other", "some", "such", "no", "nor", "not", 
                "only", "own", "same", "so", "than", "too", "very", "s", "t", "can", "will", "just", "don", 
                "should", "now"
            ])
        
    def clean_text(self, text):
        text = re.sub(r'\s+', ' ', text) # clean whitespace
        return text.strip()
        
    def process_document(self, text):
        cleaned = self.clean_text(text)
        doc = nlp(cleaned)
        
        tokens = [token.text for token in doc]
        lemmas = [token.lemma_ for token in doc if not token.is_stop and not token.is_punct]
        pos_tags = [(token.text, token.pos_) for token in doc]
        
        entities = []
        for ent in doc.ents:
            entities.append({
                "text": ent.text,
                "label": ent.label_,
                "start": ent.start_char,
                "end": ent.end_char
            })
            
        env_entities = self.extract_environmental_entities(cleaned)
        clauses = self.detect_environmental_clauses(cleaned)
        keywords = self.extract_keywords(lemmas)
        
        return {
            "tokens": tokens[:100],
            "lemmas": lemmas,
            "pos_tags": pos_tags[:100],
            "ner_entities": entities,
            "environmental_entities": env_entities,
            "detected_clauses": clauses,
            "keywords": keywords
        }
        
    def extract_environmental_entities(self, text):
        entities = []
        patterns = {
            "CHEMICAL": r"\b(SO2|NOx|CO2|Lead|Pb|Mercury|Hg|Particulate\s+Matter|PM10|PM2\.5|chlorine|PCBs|DDT|dioxins)\b",
            "PARAMETER": r"\b(pH\s+level|pH|effluent|turbidity|emissions|discharge\s+rate|discharge|stack\s+height|temperature)\b",
            "LIMIT_VALUE": r"\b\d+(\.\d+)?\s*(ppm|mg/L|mg/Nm3|tons/month|NTU|lbs/hr|mg/m3|meters|mg/kg)\b",
            "ACT_SECTION": r"\b(Section\s+\d+|Subtitle\s+[A-Z]|NPDES|RCRA|CWA|CAA|EPA)\b"
        }
        
        for label, pattern in patterns.items():
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                entities.append({
                    "text": match.group(),
                    "label": label,
                    "start": match.start(),
                    "end": match.end()
                })
        return entities
        
    def detect_environmental_clauses(self, text):
        clauses = []
        sentences = safe_sent_tokenize(text)
        
        violation_indicators = ["exceeded", "violated", "surpassed", "excessive", "discharge", "spill", "leak", "accumulation", "overrun"]
        compliance_indicators = ["compliant", "complies", "meets", "conforming", "adhered", "authorized", "permitted"]
        
        for i, sentence in enumerate(sentences):
            has_violation = any(word in sentence.lower() for word in violation_indicators)
            has_compliance = any(word in sentence.lower() for word in compliance_indicators)
            has_chem = any(word in sentence.lower() for word in ["so2", "nox", "ph", "lead", "mercury", "waste", "emissions", "discharge"])
            
            if (has_violation or has_compliance) and has_chem:
                clause_type = "VIOLATION_RISK" if has_violation else "COMPLIANCE_STANDARD"
                clauses.append({
                    "sentence_idx": i,
                    "text": sentence,
                    "type": clause_type
                })
        return clauses

    def extract_keywords(self, lemmas, top_n=10):
        freq = {}
        for word in lemmas:
            word = word.lower()
            if len(word) > 2 and word not in self.stop_words:
                freq[word] = freq.get(word, 0) + 1
        sorted_freq = sorted(freq.items(), key=lambda x: x[1], reverse=True)
        return [word for word, count in sorted_freq[:top_n]]

    def extractive_summary(self, text, num_sentences=3):
        sentences = safe_sent_tokenize(text)
        if len(sentences) <= num_sentences:
            return text
            
        doc = nlp(self.clean_text(text))
        words = [token.text.lower() for token in doc if not token.is_stop and not token.is_punct]
        
        word_frequencies = {}
        for word in words:
            word_frequencies[word] = word_frequencies.get(word, 0) + 1
            
        if not word_frequencies:
            return " ".join(sentences[:num_sentences])
            
        max_frequency = max(word_frequencies.values())
        for word in word_frequencies.keys():
            word_frequencies[word] = word_frequencies[word]/max_frequency
            
        sentence_scores = {}
        for sent in sentences:
            sentence_words = nlp(sent.lower())
            for token in sentence_words:
                if token.text in word_frequencies:
                    if len(sent.split(' ')) < 30:
                        sentence_scores[sent] = sentence_scores.get(sent, 0) + word_frequencies[token.text]
                        
        import heapq
        summary_sentences = heapq.nlargest(num_sentences, sentence_scores, key=sentence_scores.get)
        summary_sentences = sorted(summary_sentences, key=lambda x: sentences.index(x))
        return " ".join(summary_sentences)
