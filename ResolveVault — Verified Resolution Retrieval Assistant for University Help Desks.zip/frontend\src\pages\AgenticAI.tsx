import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { Bot, Sparkles, AlertTriangle, ArrowRight, UserCheck, Search, ShieldCheck } from 'lucide-react';

interface AgentTraceItem {
  agent: string;
  thought?: string;
  action?: string;
  details?: any;
}

interface AgentResponse {
  report: string;
  risk_level: string;
  agent_trace: AgentTraceItem[];
}

export default function AgenticAI() {
  const { token } = useContext(AuthContext);
  const [inputText, setInputText] = useState('');
  const [sessionHistory, setSessionHistory] = useState<any[]>([]);
  const [activeOutput, setActiveOutput] = useState<AgentResponse | null>(null);
  const [running, setRunning] = useState(false);
  const [activeAgentIdx, setActiveAgentIdx] = useState(-1);

  const agentsList = [
    "Planner Agent",
    "Retriever Agent",
    "Research Agent",
    "Compliance Agent",
    "Report Agent",
    "Verification Agent",
    "Final Response Agent"
  ];

  const handleRunAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setRunning(true);
    setActiveOutput(null);
    setActiveAgentIdx(0);

    // Simulate Agent Step Milestones
    const interval = setInterval(() => {
      setActiveAgentIdx((prev) => {
        if (prev < agentsList.length - 1) {
          return prev + 1;
        } else {
          clearInterval(interval);
          return prev;
        }
      });
    }, 1200);

    try {
      const resp = await axios.post('/api/agent/run', {
        query: inputText,
        session_id: "agent_session_1"
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      clearInterval(interval);
      setActiveAgentIdx(agentsList.length);
      setActiveOutput(resp.data);
    } catch (err: any) {
      console.error(err);
      alert("Agentic pipeline run failed.");
      clearInterval(interval);
      setActiveAgentIdx(-1);
    } finally {
      setRunning(false);
    }
  };

  const getRiskColor = (lvl: string) => {
    if (lvl === 'High') return 'text-brand-accent';
    if (lvl === 'Medium') return 'text-brand-warning';
    return 'text-brand-primary';
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-wide">Autonomous Agentic Compliance Officer</h2>
        <p className="text-xs text-gray-400 mt-1">Evolve research into cooperative multi-agent sweeps matching metrics to regulations</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Audit Inputs Panel */}
        <div className="glass-panel p-6 h-fit space-y-6">
          <div>
            <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2">
              Log Audit Inquiry
            </h3>
            <form onSubmit={handleRunAgent} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Facility Incident Description</label>
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Example: Inspect Apex Chemicals daily report. Wastewater registered pH 9.5 and lead concentrations of 0.08 mg/L."
                  rows={6}
                  required
                  className="w-full glass-input text-xs resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={running || !inputText.trim()}
                className="w-full glass-button-primary py-2.5 text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2"
              >
                <Bot className="w-4 h-4" />
                Initialize Agent Audit
              </button>
            </form>
          </div>

          {/* Collaborative Steps Trace */}
          {running && (
            <div className="space-y-2 border-t border-dark-border pt-4 animate-fadeIn">
              <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Cooperative Milestones</h4>
              <div className="space-y-1.5 text-xs">
                {agentsList.map((agt, idx) => (
                  <div 
                    key={idx} 
                    className={`flex items-center gap-2 transition ${
                      idx === activeAgentIdx 
                        ? 'text-brand-secondary font-bold animate-pulse' 
                        : idx < activeAgentIdx 
                        ? 'text-brand-primary' 
                        : 'text-gray-600'
                    }`}
                  >
                    <div className={`w-1.5 h-1.5 rounded-full ${
                      idx === activeAgentIdx 
                        ? 'bg-brand-secondary' 
                        : idx < activeAgentIdx 
                        ? 'bg-brand-primary' 
                        : 'bg-gray-700'
                    }`} />
                    <span>{agt}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Audit Output Reports */}
        <div className="glass-panel p-6 lg:col-span-2 space-y-6">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2 flex items-center justify-between">
            <span>Audited Report Output</span>
            {activeOutput && (
              <span className={`text-xs font-extrabold uppercase ${getRiskColor(activeOutput.risk_level)}`}>
                Risk Level: {activeOutput.risk_level}
              </span>
            )}
          </h3>

          {!activeOutput && !running && (
            <div className="text-center py-24 text-gray-500 space-y-2">
              <Bot className="w-16 h-16 mx-auto text-gray-600 animate-bounce" />
              <p className="text-xs">Submit an inquiry to run the agentic auditing team loop.</p>
            </div>
          )}

          {running && (
            <div className="py-20">
              <Loader message="Running Planner, Retriever, Research and Compliance agents..." />
            </div>
          )}

          {activeOutput && (
            <div className="space-y-6 animate-fadeIn">
              
              {/* Report MD */}
              <div className="p-4 rounded-xl border border-dark-border bg-dark-bg bg-opacity-40 max-h-[350px] overflow-y-auto">
                <pre className="text-xs font-sans text-gray-300 whitespace-pre-wrap leading-relaxed">
                  {activeOutput.report}
                </pre>
              </div>

              {/* Agent Thought Logs */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Agent Cognitive Thought Logs</h4>
                <div className="space-y-3 max-h-48 overflow-y-auto pr-2 border-t border-dark-border pt-3">
                  {activeOutput.agent_trace.map((trace, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-dark-panel border border-dark-border text-xs">
                      <div className="flex justify-between items-center pb-1.5 mb-1.5 border-b border-dark-border">
                        <span className="font-extrabold text-brand-secondary">{trace.agent}</span>
                        <span className="text-[10px] text-gray-500 font-mono">STEP {idx+1}</span>
                      </div>
                      
                      {trace.thought && (
                        <p className="text-gray-400 font-light italic">"Thought: {trace.thought}"</p>
                      )}
                      {trace.action && (
                        <p className="text-brand-primary mt-1 font-medium">Action: {trace.action}</p>
                      )}
                      
                      {trace.details && (
                        <details className="mt-2 text-[10px] text-gray-500 cursor-pointer">
                          <summary className="hover:text-gray-400 select-none">View action details</summary>
                          <pre className="mt-1 bg-dark-bg p-2 rounded text-gray-400 overflow-x-auto whitespace-pre-wrap font-mono">
                            {JSON.stringify(trace.details, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
