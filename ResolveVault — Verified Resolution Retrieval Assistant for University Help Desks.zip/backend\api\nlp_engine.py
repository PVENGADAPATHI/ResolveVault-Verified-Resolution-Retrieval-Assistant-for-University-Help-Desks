import sys
from fastapi import APIRouter, Depends
from pydantic import BaseModel

sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
from api.auth import get_current_user, User
from nlp.processor import LegalNLPProcessor

router = APIRouter(prefix="/nlp", tags=["NLP Processor"])
nlp_processor = LegalNLPProcessor()

class NLPRequest(BaseModel):
    text: str

@router.post("/analyze")
def analyze_text(req: NLPRequest, current_user: User = Depends(get_current_user)):
    analysis = nlp_processor.process_document(req.text)
    
    # Generate extractive summary too
    summary = nlp_processor.extractive_summary(req.text, num_sentences=2)
    analysis["summary"] = summary
    
    return analysis
