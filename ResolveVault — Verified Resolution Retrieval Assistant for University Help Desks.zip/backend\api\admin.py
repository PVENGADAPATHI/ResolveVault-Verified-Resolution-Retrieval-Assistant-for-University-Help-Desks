import sys
import psutil
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional

sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
from database.postgres import get_db, User, AuditLog, ComplianceScore
from api.auth import get_current_user

router = APIRouter(prefix="/admin", tags=["Admin Panel"])

class UserRoleUpdate(BaseModel):
    user_id: int
    role: str # admin, auditor, user

@router.get("/users")
def list_users(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin privileges required")
        
    users = db.query(User).all()
    return [
        {
            "id": u.id,
            "email": u.email,
            "role": u.role,
            "is_active": u.is_active,
            "created_at": u.created_at.strftime("%Y-%m-%d %H:%M")
        } for u in users
    ]

@router.post("/users/role")
def update_user_role(req: UserRoleUpdate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin privileges required")
        
    target = db.query(User).filter(User.id == req.user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
        
    old_role = target.role
    target.role = req.role
    
    # Audit log
    audit = AuditLog(
        user_id=current_user.id,
        action="User Role Update",
        details=f"Updated User {target.email} role from {old_role} to {req.role}"
    )
    db.add(audit)
    db.commit()
    
    return {"message": f"Successfully updated role to {req.role}"}

@router.get("/system/status")
def get_system_health(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin privileges required")
        
    # Gather CPU / RAM
    cpu = psutil.cpu_percent(interval=None)
    memory = psutil.virtual_memory().percent
    disk = psutil.disk_usage('C:').percent if sys.platform.startswith('win') else psutil.disk_usage('/').percent
    
    # Databases status checks
    from database.mongodb import db as mongo_db
    from database.redis_cache import redis_client
    
    mongo_status = "Healthy"
    try:
        # Check if Mock or real
        if hasattr(mongo_db, "collections"):
            mongo_status = "Healthy (Mock File-Mode)"
    except Exception:
        mongo_status = "Degraded"
        
    redis_status = "Healthy"
    try:
        redis_client.ping()
    except Exception:
        redis_status = "Degraded"
        
    return {
        "system": {
            "cpu_usage_pct": cpu,
            "memory_usage_pct": memory,
            "disk_usage_pct": disk,
            "os_platform": sys.platform
        },
        "databases": {
            "postgresql": "Healthy",
            "mongodb": mongo_status,
            "redis": redis_status,
            "faiss": "Initialized"
        }
    }

@router.get("/audit-logs")
def get_all_audit_logs(limit: int = 50, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin privileges required")
        
    logs = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).limit(limit).all()
    return [
        {
            "id": l.id,
            "user": l.user.email if l.user else "System",
            "action": l.action,
            "details": l.details,
            "timestamp": l.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        } for l in logs
    ]
