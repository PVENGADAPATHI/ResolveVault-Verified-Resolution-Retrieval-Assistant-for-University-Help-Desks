import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import Loader from '../components/Loader.tsx';
import { ShieldCheck, HardDrive, Database, Activity, RefreshCcw } from 'lucide-react';

interface SystemHealth {
  system: {
    cpu_usage_pct: number;
    memory_usage_pct: number;
    disk_usage_pct: number;
    os_platform: string;
  };
  databases: {
    postgresql: string;
    mongodb: string;
    redis: string;
    faiss: string;
  };
}

interface AuditLogItem {
  id: number;
  user: string;
  action: string;
  details: string;
  timestamp: string;
}

export default function AdminPanel() {
  const { token } = useContext(AuthContext);
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [logs, setLogs] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchSystemData = async () => {
    try {
      const healthResp = await axios.get('/api/admin/system/status', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const logsResp = await axios.get('/api/admin/audit-logs', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setHealth(healthResp.data);
      setLogs(logsResp.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSystemData();
  }, [token]);

  if (loading || !health) {
    return <Loader message="Accessing global server diagnostics..." />;
  }

  return (
    <div className="space-y-8 animate-fadeIn text-xs">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-white tracking-wide">Platform Administration</h2>
          <p className="text-xs text-gray-400 mt-1">Status: System telemetry running normally</p>
        </div>
        <button
          onClick={fetchSystemData}
          className="glass-button-secondary py-2 px-3 text-xs flex items-center gap-2"
        >
          <RefreshCcw className="w-3.5 h-3.5" />
          Refresh Status
        </button>
      </div>

      {/* Grid: Server Stats and Database status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Server resources */}
        <div className="glass-panel p-6 space-y-4">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider border-b border-dark-border pb-2 flex items-center gap-1.5">
            <HardDrive className="w-4 h-4 text-brand-secondary" />
            Host Resource Telemetry
          </h3>

          <div className="space-y-4 pt-2">
            <div className="space-y-1">
              <div className="flex justify-between font-semibold">
                <span className="text-gray-400">CPU Usage</span>
                <span className="text-gray-200">{health.system.cpu_usage_pct}%</span>
              </div>
              <div className="w-full h-2 bg-[#151B2C] rounded-full overflow-hidden">
                <div className="h-full bg-brand-secondary rounded-full" style={{ width: `${health.system.cpu_usage_pct}%` }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-semibold">
                <span className="text-gray-400">RAM Loading</span>
                <span className="text-gray-200">{health.system.memory_usage_pct}%</span>
              </div>
              <div className="w-full h-2 bg-[#151B2C] rounded-full overflow-hidden">
                <div className="h-full bg-brand-primary rounded-full" style={{ width: `${health.system.memory_usage_pct}%` }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-semibold">
                <span className="text-gray-400">System Disk Allocation</span>
                <span className="text-gray-200">{health.system.disk_usage_pct}%</span>
              </div>
              <div className="w-full h-2 bg-[#151B2C] rounded-full overflow-hidden">
                <div className="h-full bg-brand-warning rounded-full" style={{ width: `${health.system.disk_usage_pct}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Databases statuses */}
        <div className="glass-panel p-6 space-y-4">
          <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider border-b border-dark-border pb-2 flex items-center gap-1.5">
            <Database className="w-4 h-4 text-brand-primary" />
            Multi-Database Stack Status
          </h3>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="p-3 rounded-lg border border-dark-border bg-dark-bg bg-opacity-40">
              <span className="text-[10px] text-gray-500 uppercase block font-semibold">PostgreSQL</span>
              <span className="text-xs font-bold text-brand-primary mt-1 block flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                {health.databases.postgresql}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-dark-border bg-dark-bg bg-opacity-40">
              <span className="text-[10px] text-gray-500 uppercase block font-semibold">MongoDB</span>
              <span className="text-xs font-bold text-brand-primary mt-1 block flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                {health.databases.mongodb}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-dark-border bg-dark-bg bg-opacity-40">
              <span className="text-[10px] text-gray-500 uppercase block font-semibold">Redis Cache</span>
              <span className="text-xs font-bold text-brand-primary mt-1 block flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                {health.databases.redis}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-dark-border bg-dark-bg bg-opacity-40">
              <span className="text-[10px] text-gray-500 uppercase block font-semibold">FAISS Indices</span>
              <span className="text-xs font-bold text-brand-primary mt-1 block flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                {health.databases.faiss}
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* Global audit logs feed */}
      <div className="glass-panel p-6">
        <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-4 border-b border-dark-border pb-2 flex items-center gap-1.5">
          <Activity className="w-4 h-4 text-brand-accent" />
          Global Audit Log Feeds
        </h3>

        <div className="overflow-x-auto max-h-80 overflow-y-auto pr-2">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-dark-border text-gray-400 font-semibold uppercase">
                <th className="py-2.5 px-3">Log ID</th>
                <th className="py-2.5 px-3">Acting User</th>
                <th className="py-2.5 px-3">Category Action</th>
                <th className="py-2.5 px-3">Transaction Details</th>
                <th className="py-2.5 px-3">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-border text-gray-300">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-dark-border hover:bg-opacity-25 transition">
                  <td className="py-3 px-3 font-mono text-[10px] text-gray-500">#{log.id}</td>
                  <td className="py-3 px-3 font-bold">{log.user}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded bg-brand-secondary bg-opacity-15 text-brand-secondary font-semibold text-[10px]">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-gray-400 leading-relaxed">{log.details}</td>
                  <td className="py-3 px-3 text-gray-500 font-mono">{log.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
