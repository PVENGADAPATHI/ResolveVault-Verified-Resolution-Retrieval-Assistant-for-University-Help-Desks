import React, { useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import { Shield, Mail, Lock, AlertCircle, ArrowRight } from 'lucide-react';

export default function Login() {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      // OAuth2 request details form (x-www-form-urlencoded format for standard OAuth2PasswordRequestForm)
      const params = new URLSearchParams();
      params.append('username', email);
      params.append('password', password);

      const resp = await axios.post('/api/auth/login', params, {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      });

      const { access_token, role, email: respEmail } = resp.data;
      login(access_token, role, respEmail);
      navigate('/dashboard');
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.detail || "Incorrect username or password. Try admin@environmental.gov / admin123");
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      setError("Please fill in your email address above to trigger password reset.");
      return;
    }
    setError(null);
    try {
      const resp = await axios.post('/api/auth/forgot-password', { email });
      setForgotSent(true);
      alert(`Mock Password Reset Link Generated:\n${resp.data.reset_link}`);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Password reset failed.");
    }
  };

  const handleOAuth = async (provider: string) => {
    try {
      const testEmail = provider === 'google' ? 'google_officer@environmental.gov' : 'github_officer@environmental.gov';
      const resp = await axios.post(`/api/auth/oauth-login?provider=${provider}&email=${testEmail}`);
      const { access_token, role, email: respEmail } = resp.data;
      login(access_token, role, respEmail);
      navigate('/dashboard');
    } catch (err) {
      setError("OAuth login integration failed.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-bg p-6 relative overflow-hidden">
      <div className="absolute top-[20%] left-[30%] w-[350px] h-[350px] rounded-full bg-brand-primary bg-opacity-[0.05] filter blur-[100px] pointer-events-none" />
      
      <div className="w-full max-w-md glass-panel p-8 shadow-2xl border border-dark-border z-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-brand-primary bg-opacity-20 text-brand-primary mb-4 text-xl">
            🛡️
          </div>
          <h2 className="text-2xl font-extrabold text-white">Welcome back to Aegis</h2>
          <p className="text-xs text-gray-400 mt-1">Sign in to start environmental compliance auditing</p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-500 bg-opacity-10 border border-red-500 border-opacity-30 text-red-400 text-xs flex items-start gap-2.5 leading-relaxed">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Email Address</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="officer@company.com"
                required
                className="w-full pl-10 glass-input text-sm"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider">Password</label>
              <button
                type="button"
                onClick={handleForgotPassword}
                className="text-[11px] text-brand-secondary hover:underline"
              >
                Forgot?
              </button>
            </div>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full pl-10 glass-input text-sm"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full glass-button-primary py-2.5 text-sm font-semibold tracking-wide flex items-center justify-center gap-2 mt-6"
          >
            {loading ? "Authenticating..." : "Sign In to System"}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-dark-border" /></div>
          <div className="relative flex justify-center text-xs"><span className="bg-dark-panel px-3 text-gray-500">Or credentials connection</span></div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          <button
            type="button"
            onClick={() => handleOAuth('google')}
            className="glass-button-secondary py-2 text-xs flex items-center justify-center gap-2 bg-dark-bg bg-opacity-35"
          >
            Google OAuth
          </button>
          <button
            type="button"
            onClick={() => handleOAuth('github')}
            className="glass-button-secondary py-2 text-xs flex items-center justify-center gap-2 bg-dark-bg bg-opacity-35"
          >
            GitHub OAuth
          </button>
        </div>

        <p className="text-center text-xs text-gray-400">
          No audit account?{' '}
          <Link to="/register" className="text-brand-primary font-semibold hover:underline">
            Register Account
          </Link>
        </p>
      </div>
    </div>
  );
}
