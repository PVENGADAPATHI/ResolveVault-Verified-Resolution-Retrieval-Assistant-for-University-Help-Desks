import os
import csv
import random
import datetime
import pandas as pd
from passlib.hash import bcrypt

# Make sure directory exists
os.makedirs("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/datasets", exist_ok=True)

CSV_PATH = "C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/datasets/environmental_dataset.csv"

# 1. Generate Synthetic Compliance Logs (2,000+ entries) for ML/DL models
def generate_compliance_dataset(num_records=2000):
    random.seed(42)
    
    entities = [
        "Apex Chemicals Ltd", "GreenTech Energy Corp", "EcoMetal Refineries", 
        "Horizon Power Station", "Cascade Waste Management", "Vanguard Paper Mill",
        "Pioneer Petrochemicals", "Summit Manufacturing", "BioMed Labs Inc", "Titan Foundry"
    ]
    
    domains = ["Air Emissions", "Wastewater Discharge", "Hazardous Waste", "Chemical Safety"]
    
    # Air features: SO2 ppm (limit 100), NOx ppm (limit 120), Particulate Matter mg/m3 (limit 50)
    # Water features: pH (limit 6.0-8.5), Lead ppm (limit 0.05), Turbidity NTU (limit 10)
    # Waste features: Quantity tons/month (limit 10), Storage days (limit 90)
    
    records = []
    
    for i in range(num_records):
        entity = random.choice(entities)
        domain = random.choice(domains)
        timestamp = datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))
        
        # Initialize default features
        air_level = round(random.uniform(10.0, 180.0), 2)  # SO2 ppm
        water_ph = round(random.uniform(4.0, 11.0), 2)
        waste_qty = round(random.uniform(0.5, 25.0), 2)    # Tons/month
        lead_ppm = round(random.uniform(0.001, 0.20), 4)
        
        is_violation = 0
        risk_level = "Low"
        log_text = ""
        
        if domain == "Air Emissions":
            water_ph = 7.0  # Neutral
            lead_ppm = 0.001
            waste_qty = 0.0
            if air_level > 100.0:
                is_violation = 1
                risk_level = "High" if air_level > 140.0 else "Medium"
                log_text = f"The stack monitoring system at {entity} detected sulfur dioxide (SO2) emission levels at {air_level} ppm, exceeding the regulatory permit threshold of 100 ppm."
            else:
                risk_level = "Low"
                log_text = f"Stack emission audit at {entity} showed SO2 levels at {air_level} ppm, which complies with the clean air permit standards."
                
        elif domain == "Wastewater Discharge":
            air_level = 0.0
            waste_qty = 0.0
            if water_ph < 6.0 or water_ph > 8.5 or lead_ppm > 0.05:
                is_violation = 1
                risk_level = "High" if (water_ph < 5.0 or water_ph > 9.5 or lead_ppm > 0.10) else "Medium"
                if water_ph < 6.0 or water_ph > 8.5:
                    log_text = f"Wastewater analysis from Outfall 001 at {entity} registered an acidic/alkaline pH level of {water_ph}, violating the safe discharge range of 6.0 to 8.5."
                else:
                    log_text = f"Wastewater sampling from discharge pipe at {entity} detected lead concentrations at {lead_ppm} ppm, surpassing the EPA standard limit of 0.05 ppm."
            else:
                risk_level = "Low"
                log_text = f"Discharge water quality check at {entity} confirmed pH of {water_ph} and lead level at {lead_ppm} ppm, fully conforming to compliance guidelines."
                
        elif domain == "Hazardous Waste":
            air_level = 0.0
            water_ph = 7.0
            lead_ppm = 0.0
            if waste_qty > 10.0:
                is_violation = 1
                risk_level = "High" if waste_qty > 18.0 else "Medium"
                log_text = f"Storage log audit at {entity} revealed hazardous waste accumulation of {waste_qty} tons this month, exceeding the maximum allowed limit of 10 tons for RCRA compliance."
            else:
                risk_level = "Low"
                log_text = f"Monthly waste registry at {entity} recorded {waste_qty} tons of chemical byproduct, which is within the authorized storage limits."
                
        else:  # Chemical Safety
            # General chemical storage/safety violation based on random trigger
            air_level = round(random.uniform(5, 50), 2)
            water_ph = 7.0
            lead_ppm = 0.0
            waste_qty = round(random.uniform(0.1, 5.0), 2)
            if random.random() > 0.7:
                is_violation = 1
                risk_level = "Medium"
                log_text = f"Inspectors noted that {entity} stored flammable solvents near an active heat source at the assembly warehouse, violating fire safety and OSHA-EPA chemical storage standards."
            else:
                risk_level = "Low"
                log_text = f"Safety walkthrough at {entity} verified correct storage, labelling, and containment of all process chemicals."
                
        records.append({
            "log_id": f"LOG-{10000+i}",
            "entity_name": entity,
            "domain": domain,
            "timestamp": timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "log_text": log_text,
            "air_level": air_level,
            "water_ph": water_ph,
            "waste_qty": waste_qty,
            "lead_ppm": lead_ppm,
            "is_violation": is_violation,
            "risk_level": risk_level
        })
        
    df = pd.DataFrame(records)
    df.to_csv(CSV_PATH, index=False)
    print(f"Generated {num_records} compliance logs and saved to {CSV_PATH}")
    return df

# 2. Environmental Regulations Database (Seed Data)
environmental_acts = [
    {
        "title": "Clean Air Act (CAA) - Section 112",
        "domain": "Air Emissions",
        "text": "The Administrator shall list all categories of major sources of hazardous air pollutants. For these sources, standards shall require the maximum degree of reduction in emissions (MACT). Specifically, sulfur dioxide (SO2) levels must be maintained below 100 ppm per hour for utility stacks, and nitrogen oxide (NOx) levels must not exceed 120 ppm per hour."
    },
    {
        "title": "Clean Water Act (CWA) - Section 402",
        "domain": "Wastewater Discharge",
        "text": "National Pollutant Discharge Elimination System (NPDES) permits require facilities to monitor industrial wastewater. Under standard compliance limits, effluent pH must be maintained between 6.0 and 8.5 at all discharge points. Discharging toxic heavy metals such as Lead (Pb) exceeding 0.05 mg/L or Mercury exceeding 0.002 mg/L into public water bodies is strictly prohibited."
    },
    {
        "title": "Resource Conservation and Recovery Act (RCRA) - Subtitle C",
        "domain": "Hazardous Waste",
        "text": "Subtitle C establishes a system for controlling hazardous waste from cradle to grave. Generators of hazardous waste are prohibited from accumulating more than 10 tons of toxic sludge or waste per month, or storing hazardous residues for more than 90 days without an active permit."
    },
    {
        "title": "Indian Water (Prevention and Control of Pollution) Act, 1974 - Section 24",
        "domain": "Wastewater Discharge",
        "text": "No person shall knowingly cause or permit any poisonous, noxious or polluting matter determined in accordance with such standards as may be laid down by the State Board to enter into any stream or well or sewer or on land. The standard for water pH is set between 6.5 and 8.5 for inland surface waters."
    },
    {
        "title": "Indian Air (Prevention and Control of Pollution) Act, 1981 - Section 21",
        "domain": "Air Emissions",
        "text": "No person shall, without the previous consent of the State Board, establish or operate any industrial plant in an air pollution control area. Stack heights must conform to regulatory standards, and particulate emissions must remain below 150 mg/Nm3 for all major chimneys."
    },
    {
        "title": "EPA National Primary Drinking Water Regulations",
        "domain": "Wastewater Discharge",
        "text": "The Maximum Contaminant Level Goal (MCLG) for lead is zero. The Action Level for lead is 0.015 mg/L in water systems. Industrial facilities discharging upstream must implement advanced filtration to ensure heavy metals do not contaminate local aquifers."
    },
    {
        "title": "UN Stockholm Convention on Persistent Organic Pollutants",
        "domain": "Chemical Safety",
        "text": "Parties shall take measures to eliminate or restrict the production and use of intentionally produced persistent organic pollutants (POPs) like PCBs, DDT, and dioxins. Facilities must maintain containment integrity and prevent leaks of chemical waste."
    }
]

# 3. Seed Databases (Postgres & FAISS RAG index)
def seed_databases():
    # Import inside function to avoid circular import issues
    import sys
    sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
    
    from database.postgres import SessionLocal, User, ComplianceScore, AuditLog, init_db
    
    print("Seeding PostgreSQL database...")
    init_db()
    
    db = SessionLocal()
    try:
        # Check if already seeded
        if db.query(ComplianceScore).count() > 0:
            print("PostgreSQL already seeded. Skipping compliance score seeding.")
        else:
            df = pd.read_csv(CSV_PATH)
            # Create compliance scores
            seeded_entities = {}
            for _, row in df.iterrows():
                ent = row["entity_name"]
                if ent not in seeded_entities:
                    seeded_entities[ent] = {
                        "air": [], "water": [], "waste": [], "violations": 0
                    }
                
                # Bin features
                if row["domain"] == "Air Emissions":
                    seeded_entities[ent]["air"].append(row["air_level"])
                elif row["domain"] == "Wastewater Discharge":
                    seeded_entities[ent]["water"].append(row["water_ph"])
                elif row["domain"] == "Hazardous Waste":
                    seeded_entities[ent]["waste"].append(row["waste_qty"])
                    
                if row["is_violation"] == 1:
                    seeded_entities[ent]["violations"] += 1
            
            # Map into ComplianceScore entries
            for ent, metrics in seeded_entities.items():
                avg_air = sum(metrics["air"]) / len(metrics["air"]) if metrics["air"] else 90.0
                avg_water = sum(metrics["water"]) / len(metrics["water"]) if metrics["water"] else 7.2
                avg_waste = sum(metrics["waste"]) / len(metrics["waste"]) if metrics["waste"] else 4.5
                
                # Overall score out of 100 based on violations
                overall = max(10, 100 - (metrics["violations"] * 5))
                
                score_obj = ComplianceScore(
                    entity_name=ent,
                    overall_score=float(overall),
                    air_score=float(avg_air),
                    water_score=float(avg_water),
                    waste_score=float(avg_waste),
                    details={"total_audited_logs": len(metrics["air"]) + len(metrics["water"]) + len(metrics["waste"]), "violations": metrics["violations"]}
                )
                db.add(score_obj)
            db.commit()
            print("Seeded PostgreSQL compliance scores.")
    except Exception as e:
        print(f"Error seeding PostgreSQL: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    generate_compliance_dataset()
    seed_databases()
