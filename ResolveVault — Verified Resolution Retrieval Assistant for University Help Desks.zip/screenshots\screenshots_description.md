# SYSTEM SCREENSHOTS & INTERFACE DESCRIPTIONS

This document lists and describes the primary visual layouts, dashboards, and pages of the **Aegis** Automated Legal Research platform.

---

## 1. Landing Page
- **Visual Style**: Dark-themed, glassmorphic container cards with high-contrast emerald green highlights.
- **Components**:
  - Animated hero title header ("AEGIS Compliance Auditor").
  - Hover-animated system cards representing the RAG Search, Multi-Agent auditing, and Deep Learning engines.
  - Interactive "Get Started" call-to-action buttons redirecting to the login console.

---

## 2. Main Dashboard Panel
- **Components**:
  - Top Metric Ribbon: Displays overall Compliance Score (gauge out of 100), Active Infraction Alerts count, Audited Logs count, and average Risk Level indicator.
  - Interactive Bar/Line Charts: Renders average Air, Water, and Waste compliance scores across major industrial entities using Chart.js.
  - Recent Activities Feed: Scrollable list of recent document uploads, compliance evaluations, and system logs.

---

## 3. Document Hub & OCR Manager
- **Components**:
  - Drag-and-Drop Area: Interactive box for selecting PDF, DOCX, or TXT files.
  - Table of Uploaded files: Columns detailing Filename, Domain Medium, File Size, Word Count, Upload Time, and Actions (Delete, Audit).
  - OCR Status indicators: Displays green badges indicating successful parsing or simulated OCR translation on image-only text layers.

---

## 4. AI Chatbot & RAG Console
- **Components**:
  - Chat Window: Standard messaging layout displaying prompts and AI responses.
  - Citations Badges: Displays small clickable buttons (e.g. `[Clean Water Act Section 402]`) referencing source documents.
  - Retrieved Contexts Drawer: Slide-out panel letting developers inspect the top 3 FAISS text chunks and their relevance scores.

---

## 5. Agentic Compliance Audits Tab
- **Components**:
  - Audit Query Input: Field to request a multi-agent audit (e.g. "Verify compliance for Apex Chemicals logs").
  - Agent Progress Pipeline: Stepper component updating in real-time as each of the 7 agents (Planner, Retriever, Research, Compliance, Report, Verification, Final Response) runs.
  - Audit Output Panel: Formatted markdown audit report with violations list, references, and remediation steps.
