import React, { useState, useEffect, useContext } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { AuthContext } from '../App.tsx';
import { Bell, User, Check } from 'lucide-react';

interface NotificationItem {
  id: number;
  message: string;
  read: boolean;
  timestamp: string;
}

export default function Navbar() {
  const { email, token } = useContext(AuthContext);
  const location = useLocation();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);

  // Derive page name
  const pageNames: Record<string, string> = {
    '/dashboard': 'Compliance Control Center',
    '/documents': 'Document Hub & OCR Engine',
    '/ml': 'Traditional Machine Learning Pipeline',
    '/dl': 'Deep Learning Neural Classification',
    '/nlp': 'Natural Language Text Processor',
    '/rag': 'Regulatory Semantic RAG Engine',
    '/agentic': 'Autonomous Agentic Compliance Officer',
    '/analytics': 'Compliance Reporting & Analytics',
    '/admin': 'Global Administration Hub',
    '/profile': 'Legal Officer Profile Settings',
  };

  const currentTitle = pageNames[location.pathname] || 'Aegis Platform';

  const fetchNotifications = async () => {
    if (!token) return;
    try {
      const resp = await axios.get('/api/dashboard/notifications', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setNotifications(resp.data);
    } catch (e) {
      console.error("Notifications fetch failed", e);
    }
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 15000); // poll every 15s
    return () => clearInterval(interval);
  }, [token]);

  const markAsRead = async (id: number) => {
    try {
      await axios.post(`/api/dashboard/notifications/${id}/read`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    } catch (e) {
      console.error(e);
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="sticky top-0 z-10 flex items-center justify-between h-16 px-6 md:px-8 bg-dark-panel bg-opacity-70 backdrop-blur-md border-b border-dark-border">
      <h1 className="text-lg md:text-xl font-semibold text-white tracking-wide">
        {currentTitle}
      </h1>

      <div className="flex items-center gap-4">
        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="relative p-2 rounded-lg text-gray-400 hover:bg-dark-border hover:bg-opacity-50 hover:text-white transition-all"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 flex w-2 h-2 rounded-full bg-brand-accent animate-pulse" />
            )}
          </button>

          {showDropdown && (
            <div className="absolute right-0 mt-2 w-80 glass-panel border border-dark-border shadow-2xl z-30 p-4">
              <div className="flex justify-between items-center pb-2 border-b border-dark-border mb-2">
                <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Alert Notifications</span>
                <span className="text-[10px] bg-brand-accent bg-opacity-25 text-brand-accent px-1.5 py-0.5 rounded-full font-bold">
                  {unreadCount} New
                </span>
              </div>
              
              <div className="max-h-60 overflow-y-auto space-y-2">
                {notifications.length === 0 ? (
                  <p className="text-xs text-gray-500 text-center py-4">No notifications present</p>
                ) : (
                  notifications.map((n) => (
                    <div 
                      key={n.id} 
                      className={`p-2.5 rounded-lg border text-xs transition-all ${
                        n.read 
                          ? 'bg-transparent border-transparent text-gray-400' 
                          : 'bg-[#1c2438] bg-opacity-40 border-dark-border text-gray-200'
                      }`}
                    >
                      <div className="flex items-start gap-2 justify-between">
                        <p className="leading-relaxed flex-grow">{n.message}</p>
                        {!n.read && (
                          <button 
                            onClick={() => markAsRead(n.id)}
                            className="p-0.5 rounded hover:bg-dark-border text-brand-primary"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                      <span className="text-[9px] text-gray-500 block mt-1">{n.timestamp}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Header widget */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-dark-border bg-dark-bg bg-opacity-40">
          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-secondary bg-opacity-20 text-brand-secondary text-xs font-semibold uppercase">
            {email ? email.substring(0, 2) : 'US'}
          </div>
          <span className="hidden sm:inline text-xs text-gray-300 font-medium max-w-[120px] truncate">
            {email || 'Anonymous'}
          </span>
        </div>
      </div>
    </header>
  );
}
