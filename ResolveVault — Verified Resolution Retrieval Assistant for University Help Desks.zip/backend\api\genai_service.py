import sys
import io
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional

sys.path.append("C:/Users/sushmii/.gemini/antigravity/scratch/environmental_legal_compliance/backend")
from api.auth import get_current_user, User
from genai.gemini_service import GenerativeAIService

router = APIRouter(prefix="/genai", tags=["Generative AI"])
genai_service = GenerativeAIService()

class ReportDraftRequest(BaseModel):
    report_type: str # compliance_report, violation_report, risk_assessment, impact_summary, legal_notice, executive_summary
    entity_name: str
    violations: List[str]
    risk_level: str
    details: Optional[str] = ""

class ExportRequest(BaseModel):
    content: str
    filename: str

@router.post("/report")
def generate_draft_report(req: ReportDraftRequest, current_user: User = Depends(get_current_user)):
    try:
        context_data = {
            "entity_name": req.entity_name,
            "violations": req.violations,
            "risk_level": req.risk_level,
            "details": req.details
        }
        report = genai_service.generate_report(req.report_type, context_data)
        return {
            "report_type": req.report_type,
            "entity_name": req.entity_name,
            "content": report
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")

@router.post("/export/pdf")
def export_report_pdf(req: ExportRequest, current_user: User = Depends(get_current_user)):
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
        
        styles = getSampleStyleSheet()
        story = []
        
        # Parse content line by line and construct basic ReportLab elements
        lines = req.content.split("\n")
        
        # Add custom styles to avoid overlapping
        h1_style = ParagraphStyle('H1Style', parent=styles['Heading1'], fontSize=18, spaceAfter=12)
        h2_style = ParagraphStyle('H2Style', parent=styles['Heading2'], fontSize=14, spaceAfter=10)
        body_style = ParagraphStyle('BodyStyle', parent=styles['BodyText'], fontSize=10, spaceAfter=8)
        
        for line in lines:
            line_str = line.strip()
            if not line_str:
                story.append(Spacer(1, 10))
                continue
                
            if line_str.startswith("# "):
                story.append(Paragraph(line_str.replace("# ", ""), h1_style))
            elif line_str.startswith("## "):
                story.append(Paragraph(line_str.replace("## ", ""), h2_style))
            else:
                # Basic cleaning of markdown symbols like *, -
                clean_line = line_str.replace("**", "").replace("*", "").replace("- ", "• ")
                story.append(Paragraph(clean_line, body_style))
                
        doc.build(story)
        buffer.seek(0)
        
        return StreamingResponse(
            buffer,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={req.filename}.pdf"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF export failed: {str(e)}")

@router.post("/export/docx")
def export_report_docx(req: ExportRequest, current_user: User = Depends(get_current_user)):
    try:
        import docx
        doc = docx.Document()
        
        lines = req.content.split("\n")
        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue
                
            if line_str.startswith("# "):
                doc.add_heading(line_str.replace("# ", ""), level=1)
            elif line_str.startswith("## "):
                doc.add_heading(line_str.replace("## ", ""), level=2)
            else:
                clean_line = line_str.replace("**", "").replace("*", "")
                if clean_line.startswith("- "):
                    doc.add_paragraph(clean_line.replace("- ", ""), style='List Bullet')
                else:
                    doc.add_paragraph(clean_line)
                    
        buffer = io.BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        
        return StreamingResponse(
            buffer,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f"attachment; filename={req.filename}.docx"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DOCX export failed: {str(e)}")
