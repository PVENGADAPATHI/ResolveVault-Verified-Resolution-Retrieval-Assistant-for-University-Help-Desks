import os
import json
import asyncio
import sys
from motor.motor_asyncio import AsyncIOMotorClient

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import MONGO_URI, MONGO_DB_NAME

class MockMongoCollection:
    def __init__(self, filename):
        self.filename = f"./mock_{filename}.json"
        if not os.path.exists(self.filename):
            with open(self.filename, 'w') as f:
                json.dump([], f)
                
    def _read(self):
        try:
            with open(self.filename, 'r') as f:
                return json.load(f)
        except Exception:
            return []
            
    def _write(self, data):
        with open(self.filename, 'w') as f:
            json.dump(data, f, default=str)

    async def insert_one(self, document):
        data = self._read()
        if "_id" not in document:
            import uuid
            document["_id"] = str(uuid.uuid4())
        data.append(document)
        self._write(data)
        class InsertResult:
            def __init__(self, inserted_id):
                self.inserted_id = inserted_id
        return InsertResult(document["_id"])

    async def find_one(self, query):
        data = self._read()
        for doc in data:
            match = True
            for k, v in query.items():
                if doc.get(k) != v:
                    match = False
                    break
            if match:
                return doc
        return None

    def find(self, query=None):
        query = query or {}
        data = self._read()
        results = []
        for doc in data:
            match = True
            for k, v in query.items():
                if doc.get(k) != v:
                    match = False
                    break
            if match:
                results.append(doc)
                
        class AsyncCursor:
            def __init__(self, items):
                self.items = items
                self.idx = 0
            def __aiter__(self):
                return self
            async def __anext__(self):
                if self.idx >= len(self.items):
                    raise StopAsyncIteration
                val = self.items[self.idx]
                self.idx += 1
                return val
            async def to_list(self, length):
                return self.items[:length]
        return AsyncCursor(results)

    async def delete_one(self, query):
        data = self._read()
        new_data = []
        deleted = False
        for doc in data:
            match = True
            for k, v in query.items():
                if doc.get(k) != v:
                    match = False
                    break
            if match and not deleted:
                deleted = True
                continue
            new_data.append(doc)
        self._write(new_data)
        class DeleteResult:
            def __init__(self, count):
                self.deleted_count = count
        return DeleteResult(1 if deleted else 0)

    async def count_documents(self, query=None):
        query = query or {}
        data = self._read()
        count = 0
        for doc in data:
            match = True
            for k, v in query.items():
                if doc.get(k) != v:
                    match = False
                    break
            if match:
                count += 1
        return count

class MockMongoDB:
    def __init__(self):
        self.collections = {}
    def __getitem__(self, name):
        if name not in self.collections:
            self.collections[name] = MockMongoCollection(name)
        return self.collections[name]

try:
    client = AsyncIOMotorClient(MONGO_URI, serverSelectionTimeoutMS=2000)
    loop = asyncio.get_event_loop()
    if loop.is_running():
        db = client[MONGO_DB_NAME]
    else:
        loop.run_until_complete(client.server_info())
        db = client[MONGO_DB_NAME]
    print("MongoDB connection successful!")
except Exception as e:
    print(f"MongoDB connection failed ({e}). Falling back to file-based Mock MongoDB...")
    db = MockMongoDB()

def get_mongo_db():
    return db
