# POWERPOINT PRESENTATION SLIDES
## Title: Automated Legal Research for Environmental Law Compliance
**Academic Year**: 2025 - 2026

---

### Slide 1: Title Slide
- **Project Title**: Automated Legal Research for Environmental Law Compliance
- **Platform Name**: Aegis
- **Presented by**: Computer Science & Engineering Final Year Student
- **Key Focus**: Automated environmental audits, semantic legal retrieval, and multi-agent AI verification.

---

### Slide 2: Problem Statement
- **The Challenge**: Industrial facilities generate thousands of logs daily. Manual audits of these logs against vast legal codices are slow, expensive, and error-prone.
- **Consequences**: Unchecked toxic discharges, heavy fines, and ecological damage.
- **The Solution**: An automated AI auditor that cleanses logs, calculates compliance scores, retrieves legal sections, and drafts remediation guides.

---

### Slide 3: Objectives
- Construct high-fidelity Traditional Machine Learning models for binary violation predictions.
- Implement PyTorch Deep Learning BiLSTM + Self-Attention risk classifiers.
- Index statutory acts (CWA, CAA, RCRA) in a local FAISS Vector database.
- Orchestrate a 7-agent AI audit verification loop.
- Deliver an interactive, dark-mode React interface.

---

### Slide 4: System Architecture
- **Frontend**: React, Vite, TailwindCSS, Chart.js, Framer Motion.
- **Backend Gateway**: FastAPI, JWT/OAuth auth, Background Tasks.
- **Databases**:
  - PostgreSQL (users, audit scores)
  - MongoDB (raw uploaded files)
  - Redis (caching and sessions)
  - FAISS (dense vector indices)

---

### Slide 5: Machine Learning Module
- **Feature Extraction**: TF-IDF (1,000 max features) on compliance texts.
- **Algorithms Evaluated**: Logistic Regression, Random Forest, Decision Tree, SVM, Gradient Boosting.
- **Outputs**: Accuracy, F1-Score, ROC curves, and Feature Importance logs.

---

### Slide 6: Deep Learning Module
- **Model**: Bidirectional LSTM with Self-Attention in PyTorch.
- **Inputs**: Tokenized logs (padded/truncated to 120 tokens).
- **Target**: Risk Severity level (Low: 0, Medium: 1, High: 2).
- **Attention Output**: Captures key terms like "exceeded", "pH = 9.5", or "lead = 0.08 mg/L".

---

### Slide 7: RAG Pipeline
- **Indices**: Dense vectors via `all-MiniLM-L6-v2` encoder in FAISS + Sparse keyword index (TF-IDF).
- **Retrieval Engine**: Hybrid Search merging dense and sparse scores.
- **Context Injection**: RAG queries automatically inject statutory sections to prompt local SLMs.
- **Output**: Accurate answers with bracketed legal citations.

---

### Slide 8: Multi-Agent AI Auditor
- **Agent Roles**:
  1. Planner: Formulates 6 auditing milestones.
  2. Retriever: Connects to FAISS Vector store.
  3. Research: Summarizes regulatory limits.
  4. Compliance: Compares metrics against regulations.
  5. Report: Drafts markdown reports.
  6. Verification: Fact-checks references.
  7. Final Response: Generates clean markdown and trace trace logs.

---

### Slide 9: Results & Performance
- **Accuracy**: Both ML Random Forest and DL BiLSTM models exceed 95%.
- **Resilience**: Runs autonomously without external internet, falling back to SQLite, mock JSON databases, mock Redis, and TF-IDF vectors.
- **Execution Speed**: Formulates full compliance reports in under 5 seconds.

---

### Slide 10: Future Scope & Conclusion
- **Conclusion**: Aegis builds a secure, automated path for industrial compliance monitoring.
- **Future Enhancements**: Direct SCADA telemetry streaming, multi-lingual legal document parsing, and edge OCR cameras for on-site checks.
