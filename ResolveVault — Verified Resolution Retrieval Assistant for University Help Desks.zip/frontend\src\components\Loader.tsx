import React from 'react';

interface LoaderProps {
  message?: string;
}

export default function Loader({ message = "Analyzing and auditing dataset..." }: LoaderProps) {
  return (
    <div className="flex flex-col items-center justify-center p-8 space-y-4">
      <div className="relative w-16 h-16">
        {/* Outer glowing ring */}
        <div className="absolute inset-0 rounded-full border-4 border-brand-primary border-opacity-20 animate-pulse" />
        {/* Inner spinning segment */}
        <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-brand-primary border-r-brand-secondary animate-spin" />
      </div>
      <p className="text-sm font-semibold text-gray-300 animate-pulse uppercase tracking-wider">
        {message}
      </p>
    </div>
  );
}
