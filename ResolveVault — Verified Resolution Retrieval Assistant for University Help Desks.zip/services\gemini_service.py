import os
import requests
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import GEMINI_API_KEY

GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"

class GenerativeAIService:
    def __init__(self):
        self.api_key_valid = len(GEMINI_API_KEY) > 0
        
    def generate_report(self, report_type, context_data):
        prompt = self._build_prompt_for_type(report_type, context_data)
        
        if self.api_key_valid:
            try:
                headers = {"Content-Type": "application/json"}
                payload = {
                    "contents": [{
                        "parts": [{"text": prompt}]
                    }]
                }
                resp = requests.post(GEMINI_URL, json=payload, headers=headers, timeout=12)
                if resp.status_code == 200:
                    data = resp.json()
                    return data["candidates"][0]["content"]["parts"][0]["text"]
                else:
                    print(f"Gemini API returned status {resp.status_code}: {resp.text}")
            except Exception as e:
                print(f"Gemini API call failed ({e}). Using template builder...")
                
        return self._generate_local_template(report_type, context_data)

    def _build_prompt_for_type(self, report_type, data):
        entity = data.get("entity_name", "Unknown Facility")
        violations = data.get("violations", ["No violations recorded"])
        risk = data.get("risk_level", "Low")
        details = data.get("details", "")
        
        if report_type == "compliance_report":
            return f"Act as an Environmental Law compliance officer. Write a formal Compliance Audit Report for {entity}. Risk Level: {risk}. Violations: {', '.join(violations)}. Details: {details}."
        elif report_type == "violation_report":
            return f"Act as a government Pollution Control inspector. Write an Official environmental Violation Report for {entity} outlining the infractions: {', '.join(violations)}. Specify fine recommendations and statutory warnings."
        elif report_type == "legal_notice":
            return f"Act as a state attorney. Draft an Environmental Non-Compliance Legal Notice to {entity} regarding violations: {', '.join(violations)}. Demand remediation within 15 days under threat of injunction."
        elif report_type == "risk_assessment":
            return f"Generate an Environmental Risk Assessment for {entity}. Identify risks based on: {details}. Provide likelihood and impact levels."
        elif report_type == "impact_summary":
            return f"Draft an Environmental Impact Summary describing the ecological impact of {', '.join(violations)} released from {entity} into surrounding air, soil, or waterways."
        elif report_type == "executive_summary":
            return f"Write a high-level executive summary of the compliance audits performed for {entity}. Specify compliance score and key risk areas."
        else:
            return f"Generate suggestions and remedial recommendations for {entity} to address these environmental issues: {', '.join(violations)}."

    def _generate_local_template(self, report_type, data):
        entity = data.get("entity_name", "Specified Facility")
        violations = data.get("violations", ["No infractions identified"])
        risk = data.get("risk_level", "Low")
        
        if report_type == "compliance_report":
            return (
                f"# ENVIRONMENTAL COMPLIANCE REPORT\n\n"
                f"**Target Entity**: {entity}\n"
                f"**Audit Status**: {'NON-COMPLIANT' if risk != 'Low' else 'COMPLIANT'}\n"
                f"**Risk Severity**: {risk.upper()}\n\n"
                f"## 1. Executive Summary\n"
                f"A comprehensive environmental compliance review was conducted for {entity}. "
                f"The review evaluated operational records against standard Environmental Protection Agency (EPA) "
                f"and national environmental act thresholds.\n\n"
                f"## 2. Documented Violations & Infractions\n"
                + "\n".join([f"- **Exceedance**: {v}" for v in violations]) + "\n\n"
                f"## 3. Operations Audit Details\n"
                f"Continuous emissions stack indicators and discharge telemetry were checked. Air and effluent "
                f"values showed levels that demand operational alignment.\n\n"
                f"## 4. Immediate Compliance Directives\n"
                f"1. Implement mitigation protocols to control output streams immediately.\n"
                f"2. Calibrate flow sensors, stack scrubbers, and treatment ponds.\n"
                f"3. Submit self-reporting disclosures to state and federal databases within legal grace periods."
            )
        elif report_type == "violation_report":
            return (
                f"# OFFICIAL ENVIRONMENTAL VIOLATION REPORT\n\n"
                f"**Issued By**: Environmental Pollution Control Agency\n"
                f"**Issued To**: {entity}\n"
                f"**Violation Severity**: {risk.upper()}\n\n"
                f"## INVOLVED INFRACTIONS:\n"
                + "\n".join([f"- **Statute Violation**: Exceeded legal parameters: {v}" for v in violations]) + "\n\n"
                f"## REMEDIAL ACTION DEMAND:\n"
                f"Pursuant to the Environmental Protection Act, you are hereby ordered to halt excess discharges "
                f"and implement corrective containment. Failure to comply will result in administrative "
                fines, permit suspension, and legal prosecution."
            )
        elif report_type == "legal_notice":
            return (
                f"**FORMAL LEGAL NOTICE OF ENVIRONMENTAL NON-COMPLIANCE**\n\n"
                f"Date: July 6, 2026\n"
                f"To: Board of Directors, {entity}\n\n"
                f"RE: Notice of Intent to Sue for Clean Water Act / Clean Air Act Violations\n\n"
                f"Dear Sir/Madam,\n\n"
                f"Please take notice that {entity} is in active violation of environmental regulations, namely:\n"
                + "\n".join([f"- {v}" for v in violations]) + "\n\n"
                f"Under the citizen suit provisions of federal environmental law, we hereby demand that you cease "
                f"all illegal discharges and emissions within fifteen (15) days of this notice. If corrective "
                f"action is not taken, we intend to file a civil action in district court seeking injunctive "
                f"relief and civil penalties."
            )
        elif report_type == "risk_assessment":
            return (
                f"# ENVIRONMENTAL RISK ASSESSMENT\n\n"
                f"**Facility**: {entity}\n"
                f"**Assessed Risk Profile**: {risk.upper()}\n\n"
                f"## Risk Matrix:\n"
                f"- **Air Pollution Hazard**: Medium Probability, High Impact (exceedance triggers local ozone warnings).\n"
                f"- **Wastewater Toxicity**: High Probability, Critical Impact (discharge threatens local aquatic habitats).\n"
                f"- **Chemical Storage Risk**: Low Probability, Medium Impact (contained but lacks secondary walls).\n\n"
                f"## Mitigation Priority:\n"
                f"Primary priority is wastewater treatment neutralization. Install automated acid/caustic feed systems."
            )
        elif report_type == "impact_summary":
            return (
                f"# ENVIRONMENTAL ECOLOGICAL IMPACT SUMMARY\n\n"
                f"**Subject**: Discharge Exceedances at {entity}\n\n"
                f"## Impact Review:\n"
                f"The reported discharge events ({', '.join(violations)}) create severe biological stress in local "
                f"recipient streams. High chemical levels limit oxygen transfer and raise trace metal residues in fish "
                f"tissues. Stack particulate emissions exacerbate regional microparticle loading, causing local respiratory "
                f"concerns."
            )
        elif report_type == "executive_summary":
            return (
                f"### EXECUTIVE SUMMARY: {entity}\n"
                f"This document summarizes the audit results for {entity}. Current compliance indicates a {risk} "
                f"risk level. A total of {len(violations)} infractions are documented. Immediate facility upgrades "
                f"to scrubber columns and wastewater filtration units are recommended to ensure long-term regulatory "
                f"compliance."
            )
        else:
            return (
                f"# REMEDIATION RECOMMENDATIONS FOR {entity}\n\n"
                f"1. **Operational Controls**: Adjust raw feed chemical ratios to minimize process SO2 gas.\n"
                f"2. **Continuous Monitoring**: Integrate SCADA log exports into compliance databases.\n"
                f"3. **Training**: Educate shift supervisors on emergency spill response and neutralizer dosing."
            )
