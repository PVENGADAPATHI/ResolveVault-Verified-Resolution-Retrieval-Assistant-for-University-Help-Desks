import os
import redis
from dotenv import load_dotenv

load_dotenv()

REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = os.getenv("REDIS_PORT", "6379")
REDIS_DB = os.getenv("REDIS_DB", "0")

class MockRedis:
    def __init__(self):
        self.store = {}
        self.expiry = {}
        
    def get(self, key):
        return self.store.get(key)
        
    def set(self, key, value, ex=None):
        self.store[key] = value
        # Basic mock implementation ignores expiration or implements it loosely
        return True
        
    def delete(self, key):
        if key in self.store:
            del self.store[key]
            return 1
        return 0
        
    def incr(self, key):
        val = self.store.get(key, 0)
        try:
            val = int(val) + 1
        except ValueError:
            val = 1
        self.store[key] = str(val)
        return val
        
    def ping(self):
        return True

# Connect to Redis
try:
    redis_client = redis.Redis(host=REDIS_HOST, port=int(REDIS_PORT), db=int(REDIS_DB), socket_timeout=2)
    redis_client.ping()
    print("Redis connection successful!")
except Exception as e:
    print(f"Redis connection failed ({e}). Falling back to in-memory Mock Redis...")
    redis_client = MockRedis()

def get_redis_client():
    return redis_client
